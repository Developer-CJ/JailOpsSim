import { createApplication } from "../server/app.js";
import { chromium } from "@playwright/test";
import { mkdtemp, mkdir, rm } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const output = path.resolve(
  process.argv[2] || path.join(os.tmpdir(), "jailops-v42-preview"),
);
await mkdir(output, { recursive: true });
const dataDir = await mkdtemp(
  path.join(os.tmpdir(), "jailops-preview-records-"),
);
const runtime = createApplication({
  dataDir,
  secureCookies: false,
  loginLimit: 1000,
});
const account = {
  username: "preview.operator",
  password: randomBytes(24).toString("hex"),
};
runtime.store.createUser(account.username, account.password, "admin");
const server = runtime.app.listen(0, "127.0.0.1");
await new Promise((resolve) => server.once("listening", resolve));
const base = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({
  executablePath:
    process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
let context;
try {
  context = await browser.newContext({
    viewport: { width: 1440, height: 1000 },
    recordVideo: { dir: output, size: { width: 1440, height: 1000 } },
  });
  const session = await (
    await context.request.post(base + "/api/login", { data: account })
  ).json();
  async function command(action) {
    const snapshot = await (
      await context.request.get(base + "/api/state")
    ).json();
    const response = await context.request.post(base + "/api/actions", {
      headers: {
        "X-CSRF-Token": session.csrfToken,
        "If-Match": `"${snapshot.revision}"`,
      },
      data: action,
    });
    if (!response.ok()) throw new Error(await response.text());
    return (await response.json()).state;
  }
  async function seed(kind, answers, complete = false) {
    const state = await command({ type: "workflowStart", kind }),
      id = state.workflows.records[0].id;
    for (const [key, value] of Object.entries(answers))
      await command({ type: "workflowAnswer", id, key, value });
    if (complete) await command({ type: "workflowComplete", id });
  }
  await seed(
    "custody",
    {
      residentId: "R-1001",
      identity:
        "manual:Name and wristband checked against example transfer record",
      destination: "Education",
      escort: "Example escort team",
      handoff: "Receiving education staff acknowledged arrival.",
    },
    true,
  );
  await seed("intake", {
    name: "Robin Lane",
    age: "15",
    authority: "EXAMPLE-COURT-204",
    screening: "Concern identified · hold for assessment",
  });
  await command({
    type: "workflowStart",
    kind: "release",
    residentId: "R-1002",
  });
  const today = new Date().toISOString().slice(0, 10);
  await command({
    type: "medicationOrder",
    order: {
      residentId: "R-1001",
      medication: "Example authorized order",
      dose: "As prescribed",
      route: "Oral",
      schedule: "As documented in the example order",
      prescriber: "Example prescriber",
      reference: "EXAMPLE-RX-204",
      starts: today,
      ends: today,
    },
  });
  const page = await context.newPage(),
    errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  const pace = () => page.waitForTimeout(1200);
  const screenshot = async (name) =>
    page.screenshot({ path: path.join(root, "docs/screenshots", name) });
  const next = () =>
    page.getByRole("button", { name: "Continue", exact: true }).click();
  await page.goto(base);
  await page.locator(".path-card").first().waitFor();
  await pace();
  await screenshot("v42-desk.png");
  await page.locator(".resident-workbench").scrollIntoViewIfNeeded();
  await pace();
  await page.locator(".resident-workbench").screenshot({
    path: path.join(root, "docs/screenshots/v42-resident-workbench.png"),
  });
  await page.getByLabel("Search custody workbench").fill("R-1001");
  await page.locator(".resident-context-card").click();
  await pace();
  await screenshot("v42-custody-record.png");
  await page.getByRole("button", { name: "Timeline", exact: true }).click();
  await pace();
  await page.getByRole("button", { name: "Overview", exact: true }).click();
  await page
    .getByRole("button", { name: "Medication pass Start a guided pathway" })
    .click();
  await page.getByLabel("Authorized order").selectOption({ index: 1 });
  await next();
  await page
    .getByLabel("Two identifiers checked and source reference")
    .fill("Name and wristband checked against the example order.");
  await pace();
  await page.getByRole("button", { name: "Record manual attestation" }).click();
  await page
    .getByRole("heading", { name: "Do the administration checks agree?" })
    .waitFor();
  const checks = await page.locator(".verification-checklist input").all();
  for (const check of checks.slice(0, 3)) {
    await check.check();
    await page.waitForTimeout(250);
  }
  await screenshot("v42-medication-checks.png");
  for (const check of checks.slice(3)) await check.check();
  await page.getByRole("button", { name: /All checks complete/ }).click();
  await next();
  await page.getByRole("button", { name: "C Held", exact: true }).click();
  await next();
  await page
    .getByLabel("Document the encounter.")
    .fill(
      "Example dose held for clarification. Follow-up requested from qualified staff.",
    );
  await next();
  await page
    .getByRole("heading", { name: "Pause. Review. Confirm." })
    .waitFor();
  await pace();
  await page.getByRole("checkbox", { name: /confirm this record/ }).check();
  await page
    .getByRole("button", { name: "Commit encounter", exact: true })
    .click();
  await page.getByRole("heading", { name: "Encounter recorded." }).waitFor();
  await pace();
  await screenshot("v42-encounter-receipt.png");
  await page.getByRole("button", { name: "Continue medication round" }).click();
  await pace();
  await page.getByRole("button", { name: "Close dialog", exact: true }).click();
  await page.getByRole("button", { name: "Begin an intake" }).click();
  await page.getByLabel("Who is arriving today?").fill("Casey Lane");
  await next();
  await page.getByLabel("Age", { exact: true }).fill("16");
  await next();
  await page
    .getByLabel("What authorizes this admission?")
    .fill("EXAMPLE-ADMIT-205");
  await next();
  await page
    .getByRole("button", { name: /Completed · no unresolved concern/ })
    .click();
  await next();
  await page
    .getByRole("button", { name: "A1 room 13 available", exact: true })
    .click();
  await pace();
  await screenshot("v42-placement.png");
  await page.getByRole("button", { name: "Save & close", exact: true }).click();
  await page.locator(".shift-board").scrollIntoViewIfNeeded();
  await pace();
  await page.locator(".shift-board").screenshot({
    path: path.join(root, "docs/screenshots/v42-pathway-board.png"),
  });
  if (errors.length) throw new Error(errors.join("\n"));
  const video = page.video();
  await context.close();
  context = undefined;
  await video.saveAs(path.join(output, "JailOps-v4.2.1-workflow-preview.webm"));
  console.log(
    "Recorded a real browser walkthrough using isolated fictional fixture records:",
    path.join(output, "JailOps-v4.2.1-workflow-preview.webm"),
  );
} finally {
  if (context) await context.close();
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
  runtime.close();
  await rm(dataDir, { recursive: true, force: true });
}
