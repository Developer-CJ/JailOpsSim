import { expect, test } from "@playwright/test";
import type { Page } from "@playwright/test";
import { readFile } from "node:fs/promises";
import { testAdmin } from "./credentials.js";

test.beforeEach(async ({ page }) => {
  const login = await (
    await page.request.post("/api/login", { data: testAdmin })
  ).json();
  const snapshot = await (await page.request.get("/api/state")).json();
  expect(
    (
      await page.request.post("/api/actions", {
        headers: {
          "X-CSRF-Token": login.csrfToken,
          "If-Match": `"${snapshot.revision}"`,
        },
        data: { type: "reset" },
      })
    ).ok(),
  ).toBe(true);
});
async function command(page: Page, data: unknown) {
  const session = await (await page.request.get("/api/session")).json(),
    snapshot = await (await page.request.get("/api/state")).json();
  const response = await page.request.post("/api/actions", {
    headers: {
      "X-CSRF-Token": session.csrfToken,
      "If-Match": `"${snapshot.revision}"`,
    },
    data,
  });
  expect(response.ok(), await response.text()).toBe(true);
  return (await (await page.request.get("/api/state")).json()).state;
}
async function seedOrder(page: Page) {
  const today = new Date().toISOString().slice(0, 10);
  return (
    await command(page, {
      type: "medicationOrder",
      order: {
        residentId: "R-1001",
        medication: "Fixture authorized order",
        dose: "As prescribed",
        route: "Oral",
        schedule: "Per authoritative instruction",
        prescriber: "Fixture prescriber",
        reference: "FIXTURE-RX-2",
        starts: today,
        ends: today,
      },
    })
  ).workflows.orders[0];
}
async function next(page: Page) {
  await page.getByRole("button", { name: "Continue", exact: true }).click();
}
async function verify(page: Page) {
  await page
    .getByLabel("Two identifiers checked and source reference")
    .fill("Name and wristband checked against the fixture record.");
  await page.getByRole("button", { name: "Record manual attestation" }).click();
}

test("resident workbench filters from house pulse and launches a linked custody screen", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Browse house A2" }).click();
  const workbench = page.locator(".resident-workbench");
  await expect(workbench.locator(".resident-context-card")).toHaveCount(8);
  await expect(
    workbench.locator(".resident-card-location").first(),
  ).toContainText("A2");
  await workbench.getByRole("button", { name: "B1", exact: true }).click();
  await expect(
    workbench.locator(".resident-card-location").first(),
  ).toContainText("B1");
  await page.getByRole("button", { name: "Browse house A2" }).click();
  await expect(
    workbench.locator(".resident-card-location").first(),
  ).toContainText("A2");
  await page.getByLabel("Search custody workbench").fill("R-1013");
  await expect(workbench.locator(".resident-context-card")).toHaveCount(1);
  await workbench.locator(".resident-context-card").click();
  await expect(
    page.getByRole("heading", { name: "Custody record", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Timeline", exact: true }).click();
  await expect(page.locator(".resident-timeline")).toContainText(
    "No completed encounters",
  );
  await page.getByRole("button", { name: "Overview", exact: true }).click();
  await page
    .getByRole("button", { name: "Custody handoff Start a guided pathway" })
    .click();
  await expect(
    page.getByRole("heading", { name: "Confirm who is in front of you." }),
  ).toBeVisible();
  await expect(page.locator(".interview-context")).toContainText("R-1013");
  const state = (await (await page.request.get("/api/state")).json()).state;
  expect(state.workflows.records[0].residentId).toBe("R-1013");
  expect(state.workflows.records[0].step).toBe(1);
});

test("saving a partial answer survives reload; room grid and focus view stay interactive on mobile", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Begin an intake" }).click();
  await page
    .getByLabel("Who is arriving today?")
    .fill("Unfinished resident name");
  await page.getByRole("button", { name: "Save & close", exact: true }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await page.reload();
  await page.locator(".draft-row").first().click();
  await expect(page.getByLabel("Who is arriving today?")).toHaveValue(
    "Unfinished resident name",
  );
  await next(page);
  await page.getByLabel("Age", { exact: true }).fill("16");
  await next(page);
  await page
    .getByLabel("What authorizes this admission?")
    .fill("FIXTURE-AUTHORITY");
  await next(page);
  await page
    .getByRole("button", { name: /Completed · no unresolved concern/ })
    .click();
  await next(page);
  await expect(
    page.getByRole("button", { name: "A1 room 01 occupied", exact: true }),
  ).toBeDisabled();
  await page
    .locator(".placement-picker")
    .getByRole("button", { name: "B2 4 free", exact: true })
    .click();
  await page
    .getByRole("button", { name: "B2 room 13 available", exact: true })
    .click();
  await expect(page.getByLabel("Vacant room")).toHaveValue("B2/13");
  await page.getByRole("button", { name: "Expand workflow" }).click();
  await expect(page.locator(".interview-modal")).toHaveClass(/immersive/);
  await page.setViewportSize({ width: 390, height: 844 });
  expect(
    await page
      .locator("[role=dialog]")
      .evaluate((e) => e.scrollWidth <= e.clientWidth),
  ).toBe(true);
  await page.getByRole("button", { name: "Exit focus view" }).click();
  await page.getByRole("button", { name: "Save & close", exact: true }).click();
  await page.locator(".draft-row").first().click();
  await expect(page.getByLabel("Vacant room")).toHaveValue("B2/13");
});

test("medication round opens the correct order and requires individual checks before a given encounter", async ({
  page,
}) => {
  const order = await seedOrder(page);
  await page.goto("/");
  await page
    .locator(".shift-command-strip")
    .getByRole("button", { name: /Medication round/ })
    .click();
  await expect(page.locator(".round-row")).toHaveCount(1);
  await page.getByRole("button", { name: "Open pass", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Confirm who is in front of you." }),
  ).toBeVisible();
  await verify(page);
  await page.getByRole("button", { name: /All checks complete/ }).click();
  await expect(
    page.getByRole("button", { name: "Continue", exact: true }),
  ).toBeDisabled();
  for (const check of await page.locator(".verification-checklist input").all())
    await check.check();
  await expect(
    page.getByRole("button", { name: "Continue", exact: true }),
  ).toBeEnabled();
  await next(page);
  await page.getByRole("button", { name: "A Given", exact: true }).click();
  await next(page);
  await page
    .getByLabel("Document the encounter.")
    .fill("Fixture administration at the recorded scheduled time.");
  await next(page);
  await expect(page.locator(".review-checks span")).toHaveCount(6);
  await page.getByRole("checkbox", { name: /confirm this record/ }).check();
  await page
    .getByRole("button", { name: "Commit encounter", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Encounter recorded." }),
  ).toBeVisible();
  const downloadEvent = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export encounter" }).click();
  const download = await downloadEvent;
  const record = JSON.parse(await readFile((await download.path())!, "utf8"));
  expect(record.encounter.answers.orderId).toBe(order.id);
  expect(record.encounter.evidence.rights).toHaveLength(6);
  expect(record.encounter.status).toBe("Completed");
  await page.emulateMedia({ media: "print" });
  await expect(page.locator("#root")).toBeHidden();
  await expect(page.locator(".review-panel")).toBeVisible();
  await page.emulateMedia({ media: "screen" });
  await page.getByRole("button", { name: "Continue medication round" }).click();
  await expect(page.locator(".round-row")).toHaveCount(0);
  await page
    .getByLabel("Medication round view")
    .selectOption("All current orders");
  await expect(page.locator(".round-row")).toContainText("Given");
});

test("review edit clears downstream answers and asks for verification again", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: /03 \/ ACCOUNTABILITY/ }).click();
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1001");
  await next(page);
  await verify(page);
  await page
    .getByRole("button", { name: /Health services/, exact: false })
    .click();
  await next(page);
  await page
    .getByLabel("Who is responsible for the escort?")
    .fill("Fixture escort");
  await next(page);
  await page
    .getByLabel("Has the receiving staff accepted custody?")
    .fill("Receiving staff acknowledged arrival.");
  await next(page);
  await page
    .locator(".review-panel dl>div")
    .first()
    .getByRole("button", { name: "Edit", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Who are you working with?" }),
  ).toBeVisible();
  await expect(page.getByLabel("Resident", { exact: true })).toHaveValue(
    "R-1001",
  );
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1002");
  await next(page);
  await expect(
    page.getByRole("heading", { name: "Confirm who is in front of you." }),
  ).toBeVisible();
  const state = (await (await page.request.get("/api/state")).json()).state,
    w = state.workflows.records[0];
  expect(w.verification).toBeUndefined();
  expect(w.answers.destination).toBeUndefined();
  expect(w.residentId).toBe("R-1002");
});

test("paused board cards reopen the blocking check and filtering does not change workflow state", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Begin an intake" }).click();
  await page.getByLabel("Who is arriving today?").fill("Paused Fixture Youth");
  await next(page);
  await page.getByLabel("Age", { exact: true }).fill("15");
  await next(page);
  await page
    .getByLabel("What authorizes this admission?")
    .fill("FIXTURE-ORDER-PAUSE");
  await next(page);
  await page.getByRole("button", { name: /Concern identified/ }).click();
  await next(page);
  await page.getByRole("button", { name: "Save & return to desk" }).click();
  await expect(page.locator(".board-Paused .board-items>button")).toHaveCount(
    1,
  );
  await page.getByLabel("Filter pathway board").selectOption("release");
  await expect(page.locator(".board-Paused .board-items>button")).toHaveCount(
    0,
  );
  await page.getByLabel("Filter pathway board").selectOption("intake");
  await page.locator(".board-Paused .board-items>button").click();
  await expect(
    page.getByRole("heading", { name: "Pause this pathway." }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Revisit screening", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Has the arrival welfare screening been completed?",
    }),
  ).toBeVisible();
});

test("the original resident record opens its connected custody workbench", async ({
  page,
}) => {
  await page.goto("/#residents/R-1001");
  await page.getByRole("button", { name: "Open custody workspace" }).click();
  await expect(page).toHaveURL(/#workflow\/R-1001$/);
  await expect(
    page.getByRole("heading", { name: "Custody record", exact: true }),
  ).toBeVisible();
  await expect(page.locator(".dossier-header")).toContainText("R-1001");
});
