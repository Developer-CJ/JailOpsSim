import { workflowChecks } from "../shared/workflows.ts";
import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { createApplication } from "../server/app.js";
import { testAdmin, testOperator } from "./credentials.js";

async function fixture(overrides = {}) {
  const dir = mkdtempSync(path.join(os.tmpdir(), "jailops-api-tests-"));
  let runtime = createApplication({
    dataDir: dir,
    secureCookies: false,
    loginLimit: 1000,
    ...overrides,
  });
  runtime.store.createUser(testAdmin.username, testAdmin.password, "admin");
  runtime.store.createUser(
    testOperator.username,
    testOperator.password,
    "operator",
  );
  let server = runtime.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  let base = `http://127.0.0.1:${server.address().port}`;
  const login = async (account = testAdmin) => {
    const response = await fetch(base + "/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(account),
    });
    assert.equal(response.status, 200);
    const data = await response.json();
    return {
      cookie: response.headers.get("set-cookie").split(";")[0],
      csrf: data.csrfToken,
      user: data.user,
    };
  };
  const call = async (route, session, options = {}) =>
    fetch(base + route, {
      ...options,
      headers: {
        ...(session
          ? { Cookie: session.cookie, "X-CSRF-Token": session.csrf }
          : {}),
        ...options.headers,
      },
    });
  const state = async (session) => (await call("/api/state", session)).json();
  const action = async (payload, session, revision) =>
    call("/api/actions", session, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "If-Match": `"${revision ?? (await state(session)).revision}"`,
      },
      body: JSON.stringify(payload),
    });
  const stop = async () => {
    await new Promise((resolve) => server.close(resolve));
    runtime.close();
  };
  return {
    dir,
    runtime,
    login,
    call,
    state,
    action,
    async restart() {
      await stop();
      runtime = createApplication({
        dataDir: dir,
        secureCookies: false,
        loginLimit: 1000,
        ...overrides,
      });
      server = runtime.app.listen(0, "127.0.0.1");
      await new Promise((resolve) => server.once("listening", resolve));
      base = `http://127.0.0.1:${server.address().port}`;
    },
    async close() {
      await stop();
      rmSync(dir, { recursive: true, force: true });
    },
  };
}

test("authentication, HTTP-only sessions, CSRF, origin protection, and role enforcement", async () => {
  const f = await fixture();
  try {
    assert.equal((await f.call("/api/state")).status, 401);
    const admin = await f.login(),
      operator = await f.login(testOperator);
    const current = await f.state(admin);
    const headers = {
      "Content-Type": "application/json",
      "If-Match": `"${current.revision}"`,
      Cookie: admin.cookie,
    };
    assert.equal(
      (
        await f.call("/api/actions", null, {
          method: "POST",
          headers,
          body: JSON.stringify({ type: "secureAll" }),
        })
      ).status,
      403,
    );
    assert.equal(
      (
        await f.call("/api/actions", admin, {
          method: "POST",
          headers: { ...headers, Origin: "https://unrelated.example" },
          body: JSON.stringify({ type: "secureAll" }),
        })
      ).status,
      403,
    );
    assert.equal((await f.action({ type: "reset" }, operator)).status, 403);
    const stored = f.runtime.store.db
      .prepare("SELECT password_hash FROM users WHERE username = ?")
      .get(testAdmin.username).password_hash;
    assert.notEqual(stored, testAdmin.password);
    assert.match(stored, /^[a-f0-9]{32}:[a-f0-9]{128}$/);
    await f.call("/api/logout", admin, { method: "POST" });
    assert.equal((await f.call("/api/state", admin)).status, 401);
    assert.equal((await f.call("/api/state", operator)).status, 200);
  } finally {
    await f.close();
  }
});

test("server validates requests, interlocks, room assignments, and stale revisions", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      initial = await f.state(admin);
    assert.equal(
      (await f.action({ type: "expire", ids: ["A1-01"] }, admin)).status,
      400,
    );
    assert.equal(
      (await f.action({ type: "door", id: "missing", mode: "release" }, admin))
        .status,
      404,
    );
    assert.equal(
      (
        await f.action(
          { type: "door", id: "A1-01", mode: "hold" },
          admin,
          initial.revision,
        )
      ).status,
      200,
    );
    assert.equal(
      (await f.action({ type: "secureAll" }, admin, initial.revision)).status,
      409,
    );
    assert.equal(
      (await f.action({ type: "door", id: "A1-02", mode: "release" }, admin))
        .status,
      409,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "resident",
            id: "R-1001",
            changes: { unit: "A2", room: "01" },
          },
          admin,
        )
      ).status,
      409,
    );
    assert.equal(
      (
        await f.action(
          { type: "resident", id: "R-1001", changes: { unit: "INVALID" } },
          admin,
        )
      ).status,
      400,
    );
    const audit = await (await f.call("/api/audit", admin)).json();
    assert.equal(audit.total, 1);
    assert.equal(audit.entries[0].actor, testAdmin.username);
  } finally {
    await f.close();
  }
});

test("SQLite persists commands and accounts after restart; timer expires with no clients", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    assert.equal(
      (await f.action({ type: "door", id: "A1-01", mode: "release" }, admin))
        .status,
      200,
    );
    const before = await f.state(admin);
    await f.restart();
    const after = await f.state(admin);
    assert.equal(after.revision, before.revision);
    assert.equal(
      after.state.doors.find((d) => d.id === "A1-01").status,
      "Released",
    );
    await new Promise((resolve) => setTimeout(resolve, 8500));
    assert.equal(
      (await f.state(admin)).state.doors.find((d) => d.id === "A1-01").status,
      "Secured",
    );
    assert.equal(
      readFileSync(path.join(f.dir, "jailops.sqlite"))
        .subarray(0, 15)
        .toString(),
      "SQLite format 3",
    );
    await f.login();
  } finally {
    await f.close();
  }
});

test("panel reset and appointment conflicts are enforced by the API", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    await f.action({ type: "alarm", zone: "EDU", kind: "Fire alarm" }, admin);
    assert.equal((await f.action({ type: "resetPanel" }, admin)).status, 409);
    await f.action({ type: "acknowledge" }, admin);
    assert.equal((await f.action({ type: "resetPanel" }, admin)).status, 409);
    const { state } = await f.state(admin);
    await f.action({ type: "clearSource", id: state.alarms[0].id }, admin);
    assert.equal((await f.action({ type: "resetPanel" }, admin)).status, 200);
    assert.equal(
      (
        await f.action(
          { type: "appointment", appointment: state.appointments[0] },
          admin,
        )
      ).status,
      409,
    );
  } finally {
    await f.close();
  }
});

test("v2 database upgrade retains every existing record, account, preference, and audit row", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    await f.action({ type: "door", id: "A1-01", mode: "hold" }, admin);
    const before = await f.state(admin);
    const old = structuredClone(before.state);
    delete old.extension;
    delete old.workflows;
    old.settings.facilityName = "Preserved training campus";
    f.runtime.store.db
      .prepare("UPDATE workspace SET body = ? WHERE id = 1")
      .run(JSON.stringify(old));
    await f.restart();
    const after = await f.state(admin);
    assert.deepEqual(after.state.residents, old.residents);
    assert.deepEqual(after.state.doors, old.doors);
    assert.deepEqual(after.state.incidents, old.incidents);
    assert.deepEqual(after.state.settings, old.settings);
    assert.deepEqual(after.state.activity, old.activity);
    assert.equal(after.state.extension.schema, 1);
    assert.deepEqual(after.state.workflows, { records: [], orders: [] });
    assert.equal((await (await f.call("/api/audit", admin)).json()).total, 1);
    await f.login();
  } finally {
    await f.close();
  }
});

test("headcounts capture immutable rosters, enforce state, and preserve discrepancies", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    assert.equal(
      (await f.action({ type: "headcountStart", zone: "A1" }, admin)).status,
      200,
    );
    assert.equal(
      (await f.action({ type: "headcountStart", zone: "A1" }, admin)).status,
      409,
    );
    let count = (await f.state(admin)).state.extension.headcounts[0];
    assert.equal(count.expected.length, 12);
    assert.equal(
      (
        await f.action(
          {
            type: "headcountMark",
            id: count.id,
            residentId: "R-1040",
            present: true,
          },
          admin,
        )
      ).status,
      409,
    );
    await f.action(
      {
        type: "headcountMark",
        id: count.id,
        residentId: "R-1001",
        present: true,
      },
      admin,
    );
    await f.action({ type: "headcountFinish", id: count.id }, admin);
    assert.equal(
      (
        await f.action(
          {
            type: "headcountMark",
            id: count.id,
            residentId: "R-1001",
            present: false,
          },
          admin,
        )
      ).status,
      409,
    );
    count = (await f.state(admin)).state.extension.headcounts[0];
    assert.equal(count.expected.length - count.present.length, 11);
  } finally {
    await f.close();
  }
});

test("movement transitions, duty checks, arrival locations, and discharge cleanup are enforced", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    const initial = (await f.state(admin)).state;
    const escort = initial.staff.find((s) => s.status === "On duty").name,
      off = initial.staff.find((s) => s.status === "Off duty").name;
    const payload = {
      type: "movementCreate",
      residentId: "R-1001",
      destination: "MED",
      escort,
      purpose: "Training health appointment",
    };
    assert.equal(
      (await f.action({ ...payload, escort: off }, admin)).status,
      409,
    );
    assert.equal((await f.action(payload, admin)).status, 200);
    assert.equal((await f.action(payload, admin)).status, 409);
    let m = (await f.state(admin)).state.extension.movements[0];
    assert.equal(
      (
        await f.action(
          { type: "movementStatus", id: m.id, status: "Arrived" },
          admin,
        )
      ).status,
      409,
    );
    await f.action(
      { type: "movementStatus", id: m.id, status: "En route" },
      admin,
    );
    await f.action(
      { type: "movementStatus", id: m.id, status: "Arrived" },
      admin,
    );
    let state = (await f.state(admin)).state;
    assert.equal(state.extension.locations["R-1001"], "MED");
    assert.equal(state.residents.find((r) => r.id === "R-1001").unit, "A1");
    await f.action({ ...payload, destination: "A1" }, admin);
    await f.action(
      { type: "discharge", id: "R-1001", reason: "Community transition" },
      admin,
    );
    state = (await f.state(admin)).state;
    assert.equal(state.extension.locations["R-1001"], undefined);
    assert.equal(state.extension.movements[0].status, "Cancelled");
  } finally {
    await f.close();
  }
});

test("patrol checkpoints, intercom concurrency, and asset custody reject invalid transitions", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    const officer = (await f.state(admin)).state.staff.find(
      (s) => s.status === "On duty",
    ).name;
    await f.action({ type: "patrolStart", officer }, admin);
    const patrol = (await f.state(admin)).state.extension.patrols[0];
    assert.equal(
      (await f.action({ type: "patrolFinish", id: patrol.id }, admin)).status,
      409,
    );
    for (const c of patrol.checkpoints)
      assert.equal(
        (
          await f.action(
            {
              type: "patrolCheck",
              id: patrol.id,
              zone: c.zone,
              note: "Verified",
            },
            admin,
          )
        ).status,
        200,
      );
    assert.equal(
      (await f.action({ type: "patrolFinish", id: patrol.id }, admin)).status,
      200,
    );
    await f.action(
      { type: "intercomCreate", zone: "A1", reason: "Assistance" },
      admin,
    );
    await f.action(
      { type: "intercomCreate", zone: "A2", reason: "Question" },
      admin,
    );
    const calls = (await f.state(admin)).state.extension.calls;
    await f.action(
      { type: "intercomStatus", id: calls[0].id, status: "Connected" },
      admin,
    );
    assert.equal(
      (
        await f.action(
          { type: "intercomStatus", id: calls[1].id, status: "Connected" },
          admin,
        )
      ).status,
      409,
    );
    await f.action(
      { type: "intercomStatus", id: calls[0].id, status: "Ended" },
      admin,
    );
    assert.equal(
      (
        await f.action(
          { type: "intercomStatus", id: calls[1].id, status: "Connected" },
          admin,
        )
      ).status,
      200,
    );
    await f.action(
      { type: "assetCheckout", id: "KEY-01", holder: officer },
      admin,
    );
    assert.equal(
      (
        await f.action(
          { type: "assetCheckout", id: "KEY-01", holder: officer },
          admin,
        )
      ).status,
      409,
    );
    await f.action({ type: "assetReturn", id: "KEY-01" }, admin);
    assert.equal(
      (await f.action({ type: "assetReturn", id: "KEY-01" }, admin)).status,
      409,
    );
  } finally {
    await f.close();
  }
});

test("PA, environment, and handover validation persist shared module records after restart", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      owner = (await f.state(admin)).state.staff[0].name;
    assert.equal(
      (
        await f.action(
          {
            type: "utility",
            zone: "A1",
            lighting: "Night",
            temperature: 100,
            ventilation: "Boost",
          },
          admin,
        )
      ).status,
      400,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "announcement",
            zones: [],
            message: "Test",
            priority: "Routine",
          },
          admin,
        )
      ).status,
      400,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "announcement",
            zones: ["A1", "A1"],
            message: "Test",
            priority: "Routine",
          },
          admin,
        )
      ).status,
      400,
    );
    await f.action(
      {
        type: "utility",
        zone: "A1",
        lighting: "Night",
        temperature: 22,
        ventilation: "Boost",
      },
      admin,
    );
    await f.action(
      {
        type: "announcement",
        zones: ["A1", "EDU"],
        message: "Training briefing starts shortly",
        priority: "Routine",
      },
      admin,
    );
    await f.action(
      {
        type: "handoverCreate",
        title: "Lighting review",
        note: "Night mode verified",
        priority: "Important",
        owner,
      },
      admin,
    );
    const h = (await f.state(admin)).state.extension.handovers[0];
    await f.action({ type: "handoverFinish", id: h.id }, admin);
    await f.restart();
    const x = (await f.state(admin)).state.extension;
    assert.equal(x.utilities.A1.temperature, 22);
    assert.equal(x.announcements[0].zones.length, 2);
    assert.equal(x.handovers[0].status, "Completed");
  } finally {
    await f.close();
  }
});

test("guided fire exercise enforces actual panel response and five sequential steps", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    await f.action(
      { type: "drillStart", kind: "Fire response", zone: "EDU" },
      admin,
    );
    let s = (await f.state(admin)).state;
    const d = s.extension.drills[0];
    assert.equal(s.alarms.length, 1);
    assert.equal(
      (await f.action({ type: "drillFinish", id: d.id }, admin)).status,
      409,
    );
    assert.equal(
      (await f.action({ type: "drillStep", id: d.id, step: 1 }, admin)).status,
      409,
    );
    await f.action({ type: "drillStep", id: d.id, step: 0 }, admin);
    assert.equal(
      (await f.action({ type: "drillStep", id: d.id, step: 1 }, admin)).status,
      409,
    );
    await f.action({ type: "acknowledge" }, admin);
    await f.action({ type: "drillStep", id: d.id, step: 1 }, admin);
    await f.action({ type: "silence" }, admin);
    await f.action({ type: "drillStep", id: d.id, step: 2 }, admin);
    await f.action({ type: "clearSource", id: s.alarms[0].id }, admin);
    await f.action({ type: "drillStep", id: d.id, step: 3 }, admin);
    await f.action({ type: "resetPanel" }, admin);
    await f.action({ type: "drillStep", id: d.id, step: 4 }, admin);
    assert.equal(
      (await f.action({ type: "drillFinish", id: d.id }, admin)).status,
      200,
    );
    assert.equal((await f.state(admin)).state.extension.drills[0].score, 100);
  } finally {
    await f.close();
  }
});

async function guided(f, session, kind, answers, complete = false) {
  let response = await f.action({ type: "workflowStart", kind }, session);
  assert.equal(response.status, 200);
  const id = (await response.json()).state.workflows.records[0].id;
  for (const [key, value] of Object.entries(answers)) {
    response = await f.action(
      {
        type: "workflowAnswer",
        id,
        key,
        value,
        checks: workflowChecks(kind, key).map((c) => c.id),
      },
      session,
    );
    assert.equal(response.status, 200, await response.text());
  }
  if (complete) {
    response = await f.action({ type: "workflowComplete", id }, session);
    assert.equal(response.status, 200, await response.text());
  }
  return id;
}

test("guided intake enforces order, ownership, concern branches and atomic occupied-room checks", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      operator = await f.login(testOperator);
    let response = await f.action(
      { type: "workflowStart", kind: "intake" },
      admin,
    );
    const id = (await response.json()).state.workflows.records[0].id;
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "age", value: "15" },
          admin,
        )
      ).status,
      409,
    );
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "name", value: "Example Youth" },
          operator,
        )
      ).status,
      403,
    );
    assert.equal(
      (await f.action({ type: "workflowComplete", id }, admin)).status,
      409,
    );
    for (const [key, value] of Object.entries({
      name: "Example Youth",
      age: "16",
      authority: "COURT-FIXTURE-1",
      screening: "Concern identified · hold for assessment",
    }))
      assert.equal(
        (
          await f.action(
            {
              type: "workflowAnswer",
              id,
              key,
              value,
              checks: workflowChecks("release", key).map((c) => c.id),
            },
            admin,
          )
        ).status,
        200,
      );
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "room", value: "A1/13" },
          admin,
        )
      ).status,
      409,
    );
    await f.action({ type: "workflowBack", id }, admin);
    assert.equal(
      (
        await f.action(
          {
            type: "workflowAnswer",
            id,
            key: "screening",
            value: "Completed · no unresolved concern",
          },
          admin,
        )
      ).status,
      200,
    );
    await f.action(
      { type: "workflowAnswer", id, key: "room", value: "A1/13" },
      admin,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "workflowAnswer",
            id,
            key: "identity",
            value: "pretend-fingerprint-proof",
          },
          admin,
        )
      ).status,
      409,
    );
    for (const [key, value] of Object.entries({
      identity: "manual:Name and age checked against fixture order",
      caseManager: "Case Coordinator",
      plan: "Orientation and health review",
    }))
      assert.equal(
        (
          await f.action(
            {
              type: "workflowAnswer",
              id,
              key,
              value,
              checks: workflowChecks("release", key).map((c) => c.id),
            },
            admin,
          )
        ).status,
        200,
      );
    const other = await guided(f, admin, "intake", {
      name: "Second Youth",
      age: "15",
      authority: "COURT-FIXTURE-2",
      screening: "Completed · no unresolved concern",
      room: "A1/13",
      identity: "manual:Name and age checked against fixture order",
      caseManager: "Case Coordinator",
      plan: "Orientation",
    });
    assert.equal(
      (await f.action({ type: "workflowComplete", id }, admin)).status,
      200,
    );
    assert.equal(
      (await f.action({ type: "workflowComplete", id: other }, admin)).status,
      409,
    );
    assert.equal(
      (await f.action({ type: "workflowComplete", id }, admin)).status,
      409,
    );
    const before = await f.state(admin);
    assert.equal(
      before.state.residents.filter((r) => r.unit === "A1" && r.room === "13")
        .length,
      1,
    );
    await f.restart();
    assert.deepEqual(
      (await f.state(admin)).state.workflows,
      before.state.workflows,
    );
  } finally {
    await f.close();
  }
});

test("medication orders require admin and a current resident order; unresolved checks cannot record given", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      operator = await f.login(testOperator),
      today = new Date().toISOString().slice(0, 10);
    const order = {
      residentId: "R-1001",
      medication: "Fixture medication",
      dose: "As prescribed",
      route: "Oral",
      schedule: "Documented scheduled time",
      prescriber: "Fixture prescriber",
      reference: "FIXTURE-RX-1",
      starts: today,
      ends: today,
    };
    assert.equal(
      (await f.action({ type: "medicationOrder", order }, operator)).status,
      403,
    );
    assert.equal(
      (await f.action({ type: "medicationOrder", order }, admin)).status,
      200,
    );
    const orderId = (await f.state(admin)).state.workflows.orders[0].id;
    const wrong = await guided(f, admin, "medication", {
      residentId: "R-1002",
    });
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id: wrong, key: "orderId", value: orderId },
          admin,
        )
      ).status,
      409,
    );
    const id = await guided(f, operator, "medication", {
      residentId: "R-1001",
      orderId,
      identity: "manual:Name and wristband checked against record",
      rights: "Mismatch or concern · hold",
    });
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "outcome", value: "Given" },
          operator,
        )
      ).status,
      409,
    );
    await f.action(
      { type: "workflowAnswer", id, key: "outcome", value: "Held" },
      operator,
    );
    await f.action(
      {
        type: "workflowAnswer",
        id,
        key: "notes",
        value:
          "Held at scheduled time; nurse contacted to resolve discrepancy.",
      },
      operator,
    );
    assert.equal(
      (await f.action({ type: "workflowComplete", id }, operator)).status,
      200,
    );
    assert.equal(
      (await f.state(admin)).state.workflows.records.find((w) => w.id === id)
        .answers.outcome,
      "Held",
    );
    const discontinued = await guided(f, operator, "medication", {
      residentId: "R-1001",
      orderId,
      identity: "manual:Name and wristband checked against record",
      rights: "All checks complete",
      outcome: "Refused",
      notes: "Refused; prescriber follow-up requested.",
    });
    await f.action({ type: "medicationOrderStop", id: orderId }, admin);
    assert.equal(
      (await f.action({ type: "workflowComplete", id: discontinued }, operator))
        .status,
      409,
    );
  } finally {
    await f.close();
  }
});

test("guided custody updates location and release blocks holds then archives and cleans up connected records", async () => {
  const f = await fixture();
  try {
    const admin = await f.login();
    await guided(
      f,
      admin,
      "custody",
      {
        residentId: "R-1001",
        identity: "manual:Name and wristband checked against record",
        destination: "Health services",
        escort: "Fixture escort",
        handoff: "Receiving nurse accepted at 10:30",
      },
      true,
    );
    let state = (await f.state(admin)).state;
    assert.equal(state.extension.locations["R-1001"], "MED");
    assert.equal(state.extension.movements[0].status, "Arrived");
    const id = await guided(f, admin, "release", {
      residentId: "R-1001",
      authority: "FIXTURE-RELEASE-1",
      holds: "Hold unresolved · stop release",
    });
    assert.equal(
      (
        await f.action(
          {
            type: "workflowAnswer",
            id,
            key: "identity",
            value: "manual:Name and wristband checked against record",
          },
          admin,
        )
      ).status,
      409,
    );
    await f.action({ type: "workflowBack", id }, admin);
    for (const [key, value] of Object.entries({
      holds: "Checked · clear for release",
      identity: "manual:Name and wristband checked against record",
      recipient: "Fixture guardian; reference checked",
      property: "Reconciled and ready",
      witness: "Fixture second staff",
      reason: "Family reunification",
    }))
      assert.equal(
        (
          await f.action(
            {
              type: "workflowAnswer",
              id,
              key,
              value,
              checks: workflowChecks("release", key).map((c) => c.id),
            },
            admin,
          )
        ).status,
        200,
      );
    assert.equal(
      (await f.action({ type: "workflowComplete", id }, admin)).status,
      200,
    );
    state = (await f.state(admin)).state;
    assert.equal(
      state.residents.some((r) => r.id === "R-1001"),
      false,
    );
    assert.equal(state.discharged[0].id, "R-1001");
    assert.equal(state.extension.locations["R-1001"], undefined);
    assert.ok(state.programs.every((p) => !p.roster.includes("R-1001")));
    assert.ok(
      state.appointments
        .filter((p) => p.residentId === "R-1001")
        .every((p) => ["Completed", "Cancelled"].includes(p.status)),
    );
  } finally {
    await f.close();
  }
});

test("facility-card proofs reject wrong residents, payment tracks, replay, revocation and cross-workflow use", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      operator = await f.login(testOperator);
    const post = async (route, body, session = admin) =>
      f.call("/api/readers" + route, session, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    assert.equal(
      (
        await post(
          "/enroll",
          { residentId: "R-1001", credential: "TEST-FACILITY-123" },
          operator,
        )
      ).status,
      403,
    );
    assert.equal(
      (
        await post("/enroll", {
          residentId: "R-1001",
          credential: "%B1234^PAYMENT?",
        })
      ).status,
      400,
    );
    assert.equal(
      (
        await post("/enroll", {
          residentId: "R-1001",
          credential: "TEST-FACILITY-123",
        })
      ).status,
      200,
    );
    const raw = f.runtime.store.db
      .prepare("SELECT * FROM reader_credentials")
      .all();
    assert.equal(JSON.stringify(raw).includes("TEST-FACILITY-123"), false);
    assert.equal("reader_credentials" in (await f.state(admin)).state, false);
    const id = await guided(f, admin, "custody", { residentId: "R-1001" }),
      other = await guided(f, admin, "custody", { residentId: "R-1002" });
    assert.equal(
      (
        await post("/card", {
          workflowId: other,
          credential: "TEST-FACILITY-123",
        })
      ).status,
      409,
    );
    const proof = (
      await (
        await post("/card", { workflowId: id, credential: "TEST-FACILITY-123" })
      ).json()
    ).proof;
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id: other, key: "identity", value: proof },
          admin,
        )
      ).status,
      409,
    );
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "identity", value: proof },
          admin,
        )
      ).status,
      200,
    );
    await f.action({ type: "workflowBack", id }, admin);
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "identity", value: proof },
          admin,
        )
      ).status,
      409,
    );
    await post("/revoke", { residentId: "R-1001" });
    assert.equal(
      (await post("/card", { workflowId: id, credential: "TEST-FACILITY-123" }))
        .status,
      409,
    );
    await f.action({ type: "reset" }, admin);
    assert.equal(
      f.runtime.store.db
        .prepare("SELECT count(*) AS n FROM reader_credentials")
        .get().n,
      0,
    );
  } finally {
    await f.close();
  }
});

test("WBF signed assertions bind the staff user, subject, expiry and nonce, without accepting arbitrary scan success", async () => {
  const { createHmac, randomBytes } = await import("node:crypto");
  const fingerprintKey = randomBytes(32).toString("hex");
  const f = await fixture({ fingerprintKey });
  try {
    const admin = await f.login(),
      operator = await f.login(testOperator);
    const post = async (route, body, session = admin) =>
      f.call("/api/readers" + route, session, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    const id = await guided(f, admin, "custody", { residentId: "R-1001" });
    const c = await (await post("/challenge", { workflowId: id })).json();
    const signature = createHmac("sha256", fingerprintKey)
      .update(`${c.nonce}\n${c.subject}\n${c.operator}\nstaff-wbf-matched`)
      .digest("hex");
    const assertion = {
      nonce: c.nonce,
      subject: c.subject,
      residentCheck: "Name and wristband checked against record",
      signature,
    };
    assert.equal(
      (await post("/fingerprint", { ...assertion, signature: "0".repeat(64) }))
        .status,
      403,
    );
    assert.equal((await post("/fingerprint", assertion, operator)).status, 409);
    assert.equal(
      (await post("/fingerprint", { ...assertion, subject: "R-1002" })).status,
      409,
    );
    const response = await post("/fingerprint", assertion);
    assert.equal(response.status, 200);
    const proof = (await response.json()).proof;
    assert.equal((await post("/fingerprint", assertion)).status, 409);
    assert.equal(
      (
        await f.action(
          { type: "workflowAnswer", id, key: "identity", value: proof },
          admin,
        )
      ).status,
      200,
    );
    const record = (await f.state(admin)).state.workflows.records.find(
      (w) => w.id === id,
    );
    assert.match(record.verification.method, /Staff fingerprint · WBF/);
    const c2 = await (await post("/challenge", { workflowId: id })).json();
    f.runtime.store.db
      .prepare("UPDATE reader_challenges SET expires=0 WHERE nonce=?")
      .run(c2.nonce);
    const s2 = createHmac("sha256", fingerprintKey)
      .update(`${c2.nonce}\n${c2.subject}\n${c2.operator}\nstaff-wbf-matched`)
      .digest("hex");
    assert.equal(
      (
        await post("/fingerprint", {
          ...assertion,
          nonce: c2.nonce,
          signature: s2,
        })
      ).status,
      409,
    );
  } finally {
    await f.close();
  }
});

test("context launches validate resident and order; drafts persist and revisiting clears later verification", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      other = await f.login(testOperator);
    assert.equal(
      (
        await f.action(
          { type: "workflowStart", kind: "intake", residentId: "R-1001" },
          admin,
        )
      ).status,
      409,
    );
    assert.equal(
      (
        await f.action(
          { type: "workflowStart", kind: "custody", residentId: "R-missing" },
          admin,
        )
      ).status,
      409,
    );
    let response = await f.action(
      { type: "workflowStart", kind: "custody", residentId: "R-1001" },
      admin,
    );
    const id = (await response.json()).state.workflows.records[0].id;
    let w = (await f.state(admin)).state.workflows.records[0];
    assert.equal(w.step, 1);
    assert.equal(w.residentSnapshot.id, "R-1001");
    assert.equal(
      (
        await f.action(
          {
            type: "workflowDraft",
            id,
            key: "identity",
            value: "reader-secret-must-not-save",
          },
          admin,
        )
      ).status,
      409,
    );
    await f.action(
      {
        type: "workflowAnswer",
        id,
        key: "identity",
        value: "manual:Name and wristband checked against record",
      },
      admin,
    );
    await f.action(
      {
        type: "workflowAnswer",
        id,
        key: "destination",
        value: "Health services",
      },
      admin,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "workflowDraft",
            id,
            key: "escort",
            value: "An unfinished escort note",
          },
          other,
        )
      ).status,
      403,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "workflowDraft",
            id,
            key: "escort",
            value: "An unfinished escort note",
          },
          admin,
        )
      ).status,
      200,
    );
    await f.restart();
    w = (await f.state(admin)).state.workflows.records.find((w) => w.id === id);
    assert.equal(w.draft.value, "An unfinished escort note");
    assert.equal(w.step, 3);
    assert.equal(
      (await f.action({ type: "workflowRevisit", id, step: 4 }, admin)).status,
      409,
    );
    assert.equal(
      (await f.action({ type: "workflowRevisit", id, step: 0 }, admin)).status,
      200,
    );
    w = (await f.state(admin)).state.workflows.records.find((w) => w.id === id);
    assert.equal(w.verification, undefined);
    assert.deepEqual(w.answers, {});
    assert.equal(w.residentId, "");
    assert.equal(w.draft.value, "R-1001");
    assert.equal(
      (await f.action({ type: "workflowComplete", id }, admin)).status,
      409,
    );
  } finally {
    await f.close();
  }
});

test("new medication checks need individual evidence and retain a closed resident snapshot", async () => {
  const f = await fixture();
  try {
    const admin = await f.login(),
      today = new Date().toISOString().slice(0, 10);
    await f.action(
      {
        type: "medicationOrder",
        order: {
          residentId: "R-1001",
          medication: "Fixture order",
          dose: "As ordered",
          route: "Oral",
          schedule: "Per order",
          prescriber: "Fixture prescriber",
          reference: "FIXTURE-RX-42",
          starts: today,
          ends: today,
        },
      },
      admin,
    );
    const orderId = (await f.state(admin)).state.workflows.orders[0].id;
    assert.equal(
      (
        await f.action(
          {
            type: "workflowStart",
            kind: "medication",
            residentId: "R-1002",
            orderId,
          },
          admin,
        )
      ).status,
      409,
    );
    const opened = await f.action(
        {
          type: "workflowStart",
          kind: "medication",
          residentId: "R-1001",
          orderId,
        },
        admin,
      ),
      w = (await opened.json()).state.workflows.records[0];
    assert.equal(w.step, 2);
    await f.action(
      {
        type: "workflowAnswer",
        id: w.id,
        key: "identity",
        value: "manual:Name and wristband checked against record",
      },
      admin,
    );
    const payload = {
      type: "workflowAnswer",
      id: w.id,
      key: "rights",
      value: "All checks complete",
    };
    assert.equal((await f.action(payload, admin)).status, 409);
    assert.equal(
      (await f.action({ ...payload, checks: ["person", "dose"] }, admin))
        .status,
      409,
    );
    assert.equal(
      (await f.action({ ...payload, checks: ["person", "person"] }, admin))
        .status,
      409,
    );
    const checks = workflowChecks("medication", "rights").map((c) => c.id);
    assert.equal((await f.action({ ...payload, checks }, admin)).status, 200);
    await f.action(
      { type: "workflowAnswer", id: w.id, key: "outcome", value: "Given" },
      admin,
    );
    await f.action(
      {
        type: "workflowAnswer",
        id: w.id,
        key: "notes",
        value: "Fixture administration at the documented scheduled time.",
      },
      admin,
    );
    await f.action({ type: "workflowComplete", id: w.id }, admin);
    let closed = (await f.state(admin)).state.workflows.records.find(
      (r) => r.id === w.id,
    );
    assert.deepEqual(closed.evidence.rights, checks);
    const name = closed.residentSnapshot.name;
    const snapshot = await f.state(admin);
    snapshot.state.residents.find((r) => r.id === "R-1001").name =
      "Fixture edited name";
    f.runtime.store.db
      .prepare("UPDATE workspace SET body=? WHERE id=1")
      .run(JSON.stringify(snapshot.state));
    closed = (await f.state(admin)).state.workflows.records.find(
      (r) => r.id === w.id,
    );
    assert.equal(closed.residentSnapshot.name, name);
    assert.equal(
      (await f.action({ type: "workflowRevisit", id: w.id, step: 0 }, admin))
        .status,
      409,
    );
    assert.equal(
      (
        await f.action(
          {
            type: "workflowDraft",
            id: w.id,
            key: "notes",
            value: "Altered after completion",
          },
          admin,
        )
      ).status,
      409,
    );
  } finally {
    await f.close();
  }
});
