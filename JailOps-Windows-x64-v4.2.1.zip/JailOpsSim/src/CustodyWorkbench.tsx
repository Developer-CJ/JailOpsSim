import { useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarClock,
  Check,
  CheckCircle2,
  ClipboardList,
  Clock3,
  HeartPulse,
  MapPin,
  Search,
  ShieldCheck,
  UserRound,
  Users,
} from "lucide-react";
import { Modal } from "./components";
import { useSimulation } from "./store";
import { questions, workflowPaused } from "../shared/workflows";
import type { Workflow, WorkflowKind } from "../shared/workflows";
import type { Page, Resident } from "./model";
export const initials = (name: string) =>
  name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
export const pathwayName = (kind: WorkflowKind) =>
  ({
    intake: "Intake",
    medication: "Medication pass",
    custody: "Custody handoff",
    release: "Release",
  })[kind];
export type LaunchWorkflow = (
  kind: WorkflowKind,
  residentId?: string,
  orderId?: string,
) => Promise<void>;
export function PersonPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  const { state } = useSimulation();
  const [query, setQuery] = useState(""),
    [unit, setUnit] = useState("All");
  const matches = state.residents.filter(
    (r) =>
      (unit === "All" || r.unit === unit) &&
      `${r.name} ${r.id} ${r.room}`.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <div className="person-picker">
      <label className="person-search">
        <Search size={18} />
        <input
          aria-label="Find a resident"
          placeholder="Search name, ID or room…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </label>
      <div className="unit-pills" aria-label="Resident houses">
        {["All", "A1", "A2", "B1", "B2"].map((u) => (
          <button
            type="button"
            key={u}
            aria-pressed={unit === u}
            onClick={() => setUnit(u)}
          >
            {u}
          </button>
        ))}
      </div>
      <div className="person-tiles">
        {matches.slice(0, 8).map((r) => (
          <button
            type="button"
            className={value === r.id ? "selected" : ""}
            aria-pressed={value === r.id}
            key={r.id}
            onClick={() => onChange(r.id)}
          >
            <span className={`resident-monogram house-${r.unit}`}>
              {initials(r.name)}
            </span>
            <span>
              <strong>{r.name}</strong>
              <small>
                {r.id} · {r.unit}/{r.room}
              </small>
            </span>
            {value === r.id ? (
              <CheckCircle2 size={18} />
            ) : (
              <ArrowRight size={16} />
            )}
          </button>
        ))}
      </div>
      {!matches.length && (
        <p className="workbench-empty">
          No matching residents. Try another name, ID, or house.
        </p>
      )}
      <label className="picker-fallback">
        Select any record
        <select
          required
          aria-label="Resident"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        >
          <option value="">Choose resident…</option>
          {state.residents.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name} · {r.id} · {r.unit}/{r.room}
            </option>
          ))}
        </select>
      </label>
    </div>
  );
}
export function PlacementPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  const { state } = useSimulation();
  const [unit, setUnit] = useState(
    ["A1", "A2", "B1", "B2"].includes(value.split("/")[0])
      ? value.split("/")[0]
      : "A1",
  );
  const occupant = (room: string) =>
    state.residents.find((r) => r.unit === unit && r.room === room);
  return (
    <div className="placement-picker">
      <div className="unit-pills" aria-label="Placement houses">
        {["A1", "A2", "B1", "B2"].map((u) => (
          <button
            type="button"
            key={u}
            aria-pressed={unit === u}
            onClick={() => setUnit(u)}
          >
            {u}
            <span>
              {16 - state.residents.filter((r) => r.unit === u).length} free
            </span>
          </button>
        ))}
      </div>
      <div className="room-plan-heading">
        <MapPin size={16} />
        <strong>HOUSE {unit}</strong>
        <span>Choose an available room</span>
      </div>
      <div className="room-plan">
        {Array.from({ length: 16 }, (_, i) => `${i + 1}`.padStart(2, "0")).map(
          (room) => {
            const person = occupant(room),
              id = `${unit}/${room}`;
            return (
              <button
                type="button"
                key={room}
                disabled={!!person}
                aria-pressed={value === id}
                aria-label={`${unit} room ${room} ${person ? "occupied" : "available"}`}
                className={person ? "occupied" : value === id ? "selected" : ""}
                onClick={() => onChange(id)}
              >
                <span>
                  {value === id ? (
                    <Check size={16} />
                  ) : person ? (
                    <UserRound size={16} />
                  ) : (
                    <PlusRoom />
                  )}
                </span>
                <strong>{room}</strong>
                <small>
                  {person
                    ? "Occupied"
                    : value === id
                      ? "Selected"
                      : "Available"}
                </small>
              </button>
            );
          },
        )}
      </div>
      <p className="placement-note">
        Placement availability only. Staff must assess suitability against
        current placement requirements.
      </p>
      <label className="picker-fallback">
        Selected placement
        <select
          required
          aria-label="Vacant room"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setUnit(e.target.value.split("/")[0] || "A1");
          }}
        >
          <option value="">Choose room…</option>
          {["A1", "A2", "B1", "B2"].flatMap((u) =>
            Array.from({ length: 16 }, (_, i) => `${i + 1}`.padStart(2, "0"))
              .filter(
                (room) =>
                  !state.residents.some((r) => r.unit === u && r.room === room),
              )
              .map((room) => (
                <option key={`${u}/${room}`}>
                  {u}/{room}
                </option>
              )),
          )}
        </select>
      </label>
    </div>
  );
}
function PlusRoom() {
  return <span aria-hidden="true">+</span>;
}
export function ResidentWorkbench({
  start,
  navigate,
  initialResidentId,
  houseFocus,
  onHouseChange,
}: {
  start: LaunchWorkflow;
  navigate: (page: Page, id?: string) => void;
  initialResidentId?: string;
  houseFocus: string;
  onHouseChange: (unit: string) => void;
}) {
  const { state } = useSimulation();
  const [query, setQuery] = useState(""),
    [profile, setProfile] = useState(initialResidentId || "");
  const unit = houseFocus,
    setUnit = onHouseChange;
  const matches = state.residents.filter(
    (r) =>
      (unit === "All" || r.unit === unit) &&
      `${r.name} ${r.id}`.toLowerCase().includes(query.toLowerCase()),
  );
  const person = state.residents.find((r) => r.id === profile);
  return (
    <section className="resident-workbench">
      <div className="desk-section-title">
        <div>
          <span className="desk-label">PERSON → CONTEXT → ACTION</span>
          <h2>Start with someone.</h2>
        </div>
        <span>Open a custody record. Pick the next step.</span>
      </div>
      <div className="workbench-toolbar">
        <label className="person-search">
          <Search size={18} />
          <input
            aria-label="Search custody workbench"
            placeholder="Find a name or resident ID…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <div className="unit-pills">
          {["All", "A1", "A2", "B1", "B2"].map((u) => (
            <button
              key={u}
              aria-pressed={unit === u}
              onClick={() => setUnit(u)}
            >
              {u === "All" ? "All houses" : u}
            </button>
          ))}
        </div>
      </div>
      <div className="resident-card-grid">
        {matches.slice(0, 8).map((r) => {
          const active = state.workflows.records.filter(
            (w) => w.residentId === r.id && w.status === "Draft",
          );
          return (
            <button
              key={r.id}
              className="resident-context-card"
              onClick={() => setProfile(r.id)}
            >
              <div>
                <span className={`resident-monogram house-${r.unit}`}>
                  {initials(r.name)}
                </span>
                <span className="resident-status">{r.status}</span>
              </div>
              <h3>{r.name}</h3>
              <p>
                {r.id} <span>· {r.age} years</span>
              </p>
              <div className="resident-card-location">
                <MapPin size={13} />
                {state.extension.locations[r.id] || r.unit} / room {r.room}
              </div>
              <footer>
                <span>
                  {active.length
                    ? `${active.length} open pathway${active.length === 1 ? "" : "s"}`
                    : "Open custody record"}
                </span>
                <ArrowUpRight size={17} />
              </footer>
            </button>
          );
        })}
      </div>
      {!matches.length && (
        <p className="workbench-empty">No matching records in this house.</p>
      )}
      <div className="workbench-count">
        Showing {Math.min(matches.length, 8)} of {matches.length} matches
        <button onClick={() => navigate("residents")}>
          Full resident directory <ArrowUpRight size={14} />
        </button>
      </div>
      {person && (
        <ResidentDossier
          person={person}
          start={async (...args) => {
            setProfile("");
            await start(...args);
          }}
          onClose={() => setProfile("")}
          navigate={navigate}
        />
      )}
    </section>
  );
}
function ResidentDossier({
  person: r,
  start,
  onClose,
  navigate,
}: {
  person: Resident;
  start: LaunchWorkflow;
  onClose: () => void;
  navigate: (page: Page, id?: string) => void;
}) {
  const { state, user, pending } = useSimulation();
  const [tab, setTab] = useState("Overview");
  const related = state.workflows.records.filter((w) => w.residentId === r.id);
  const movements = state.extension.movements.filter(
    (m) => m.residentId === r.id,
  );
  const events = [
    ...related
      .filter((w) => w.status === "Completed")
      .map((w) => ({
        id: w.id,
        time: w.completed!,
        title: pathwayName(w.kind),
        detail: `${w.answers.outcome || w.answers.reason || "Encounter complete"} · ${w.owner}`,
      })),
    ...movements.map((m) => ({
      id: m.id,
      time: m.updated,
      title: `Movement · ${m.status}`,
      detail: `${m.origin} → ${m.destination} · ${m.escort}`,
    })),
  ].sort((a, b) => b.time.localeCompare(a.time));
  const orders = state.workflows.orders.filter((o) => o.residentId === r.id);
  return (
    <Modal
      wide
      title="Custody record"
      subtitle="Resident context & connected pathways"
      onClose={onClose}
    >
      <div className="dossier">
        <header className="dossier-header">
          <span className={`resident-monogram house-${r.unit}`}>
            {initials(r.name)}
          </span>
          <div>
            <span className="desk-label">
              {r.id} / {r.age} YEARS
            </span>
            <h2>{r.name}</h2>
            <p>
              <MapPin size={14} />
              {r.unit} / room {r.room} · {r.status}
            </p>
          </div>
          <span className="dossier-record-status">
            <i /> In custody
          </span>
        </header>
        <nav className="dossier-tabs" aria-label="Resident record sections">
          {["Overview", "Timeline", "Medication orders"].map((t) => (
            <button key={t} aria-pressed={tab === t} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </nav>
        {tab === "Overview" ? (
          <div className="dossier-overview">
            <section>
              <span className="desk-label">NEXT ACTION</span>
              <div className="dossier-actions">
                {(["medication", "custody", "release"] as const).map((kind) => (
                  <button
                    key={kind}
                    disabled={pending}
                    onClick={() => void start(kind, r.id)}
                  >
                    {kind === "medication" ? (
                      <HeartPulse size={22} />
                    ) : kind === "custody" ? (
                      <Users size={22} />
                    ) : (
                      <ShieldCheck size={22} />
                    )}
                    <span>
                      {pathwayName(kind)}
                      <small>Start a guided pathway</small>
                    </span>
                    <ArrowRight size={18} />
                  </button>
                ))}
              </div>
              <p className="dossier-care-plan">
                <strong>Immediate plan</strong>
                {r.plan}
                <small>Case coordinator · {r.caseManager}</small>
              </p>
            </section>
            <aside>
              <span className="desk-label">IN CONTEXT</span>
              <div className="dossier-fact">
                <CalendarClock size={18} />
                <div>
                  <small>Admission</small>
                  <strong>{new Date(r.admitted).toLocaleDateString()}</strong>
                </div>
              </div>
              <div className="dossier-fact">
                <HeartPulse size={18} />
                <div>
                  <small>Authorized orders</small>
                  <strong>
                    {orders.filter((o) => o.active).length} active
                  </strong>
                </div>
              </div>
              <div className="dossier-fact">
                <ClipboardList size={18} />
                <div>
                  <small>Open pathways</small>
                  <strong>
                    {related.filter((w) => w.status === "Draft").length} in
                    progress
                  </strong>
                </div>
              </div>
              <button
                className="dossier-directory"
                onClick={() => {
                  onClose();
                  navigate("residents", r.id);
                }}
              >
                Placement & care record <ArrowUpRight size={16} />
              </button>
              <small className="dossier-permission">
                Signed in as {user.username}
              </small>
            </aside>
          </div>
        ) : tab === "Timeline" ? (
          <div className="resident-timeline">
            {events.length ? (
              events.map((event) => (
                <div key={event.id}>
                  <span>
                    <Clock3 size={17} />
                  </span>
                  <div>
                    <time>{new Date(event.time).toLocaleString()}</time>
                    <h3>{event.title}</h3>
                    <p>{event.detail}</p>
                  </div>
                </div>
              ))
            ) : (
              <p>
                No completed encounters or movements for this resident yet. New
                actions will appear here.
              </p>
            )}
          </div>
        ) : (
          <div className="dossier-orders">
            {orders.length ? (
              orders.map((o) => (
                <div key={o.id}>
                  <HeartPulse size={20} />
                  <div>
                    <strong>
                      {o.medication} · {o.dose}
                    </strong>
                    <p>
                      {o.route} / {o.schedule}
                    </p>
                    <small>
                      {o.prescriber} · {o.reference} ·{" "}
                      {o.active ? "Active" : "Discontinued"}
                    </small>
                  </div>
                </div>
              ))
            ) : (
              <p>No authorized medication orders are recorded.</p>
            )}
          </div>
        )}
      </div>
    </Modal>
  );
}
export function ShiftBoard({ open }: { open: (id: string) => void }) {
  const { state, user } = useSimulation();
  const [kind, setKind] = useState("All"),
    [query, setQuery] = useState("");
  const mine = state.workflows.records.filter(
    (w) =>
      w.owner === user.username &&
      w.status !== "Cancelled" &&
      (kind === "All" || w.kind === kind) &&
      `${w.answers.name || state.residents.find((r) => r.id === w.residentId)?.name || ""} ${w.id}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  const columns = [
    {
      id: "Paused",
      title: "Needs a decision",
      detail: "Resolve the recorded concern",
      match: (w: Workflow) => workflowPaused(w),
    },
    {
      id: "Active",
      title: "In progress",
      detail: "Keep the next check moving",
      match: (w: Workflow) => w.status === "Draft" && !workflowPaused(w),
    },
    {
      id: "Completed",
      title: "Recorded",
      detail: "Closed with an audit entry",
      match: (w: Workflow) => w.status === "Completed",
    },
  ];
  return (
    <section className="shift-board">
      <div className="desk-section-title">
        <div>
          <span className="desk-label">A SHIFT IN MOTION</span>
          <h2>Your pathway board.</h2>
        </div>
        <select
          aria-label="Filter pathway board"
          value={kind}
          onChange={(e) => setKind(e.target.value)}
        >
          {["All", "intake", "medication", "custody", "release"].map((k) => (
            <option key={k} value={k}>
              {k === "All" ? "All pathways" : pathwayName(k as WorkflowKind)}
            </option>
          ))}
        </select>
      </div>
      <label className="person-search board-search">
        <Search size={17} />
        <input
          aria-label="Search pathway board"
          placeholder="Find a resident or encounter…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </label>
      <div className="board-columns">
        {columns.map((column) => {
          const rows = mine.filter(column.match);
          return (
            <div className={`board-column board-${column.id}`} key={column.id}>
              <header>
                <div>
                  <i />
                  <h3>{column.title}</h3>
                  <b>{rows.length}</b>
                </div>
                <p>{column.detail}</p>
              </header>
              <div className="board-items">
                {rows.slice(0, 6).map((w) => (
                  <button key={w.id} onClick={() => open(w.id)}>
                    <span className="desk-label">{pathwayName(w.kind)}</span>
                    <strong>
                      {w.answers.name ||
                        state.residents.find((r) => r.id === w.residentId)
                          ?.name ||
                        state.discharged.find((r) => r.id === w.residentId)
                          ?.name ||
                        "Person not selected"}
                    </strong>
                    <p>
                      {w.status === "Completed"
                        ? w.answers.outcome ||
                          w.answers.reason ||
                          "Encounter recorded"
                        : workflowPaused(w)
                          ? "Paused · resolve the concern"
                          : questions(w.kind)[w.step]?.title ||
                            "Ready for final review"}
                    </p>
                    <span className="board-card-footer">
                      {w.step}/{questions(w.kind).length} checks{" "}
                      {w.status === "Completed" ? (
                        <CheckCircle2 size={15} />
                      ) : (
                        <ArrowRight size={15} />
                      )}
                    </span>
                  </button>
                ))}
                {rows.length === 0 && (
                  <div className="board-placeholder">
                    <ClipboardList size={21} />
                    <span>
                      {column.id === "Paused"
                        ? "No paused pathways"
                        : column.id === "Active"
                          ? "Ready for the next encounter"
                          : "Completed work appears here"}
                    </span>
                  </div>
                )}
                {rows.length > 6 && (
                  <small>
                    {rows.length - 6} more records · use search to narrow the
                    board
                  </small>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
export function MedicationRound({
  start,
  onClose,
}: {
  start: LaunchWorkflow;
  onClose: () => void;
}) {
  const { state } = useSimulation();
  const [unit, setUnit] = useState("All"),
    [view, setView] = useState("Awaiting encounter");
  const today = new Date().toISOString().slice(0, 10);
  const orders = state.workflows.orders.filter(
    (o) =>
      o.active &&
      o.starts <= today &&
      o.ends >= today &&
      state.residents.some(
        (r) => r.id === o.residentId && (unit === "All" || r.unit === unit),
      ),
  );
  const encounters = (id: string) =>
    state.workflows.records.filter(
      (w) =>
        w.kind === "medication" &&
        w.answers.orderId === id &&
        w.status === "Completed" &&
        w.completed?.slice(0, 10) === today,
    );
  const pendingOrders = orders.filter((o) => encounters(o.id).length === 0),
    shown = view === "Awaiting encounter" ? pendingOrders : orders;
  return (
    <Modal
      wide
      title="Medication round"
      subtitle="Work one authorized order and resident at a time"
      onClose={onClose}
    >
      <div className="medication-round">
        <div className="round-banner">
          <HeartPulse size={35} />
          <div>
            <span className="desk-label">TODAY / {today} UTC</span>
            <h2>
              {pendingOrders.length}
              <span> orders awaiting an encounter</span>
            </h2>
            <p>
              Queue reflects current orders and today’s records. Check the
              actual administration schedule before starting.
            </p>
          </div>
        </div>
        <div className="workbench-toolbar">
          <div className="unit-pills">
            {["All", "A1", "A2", "B1", "B2"].map((u) => (
              <button
                key={u}
                aria-pressed={unit === u}
                onClick={() => setUnit(u)}
              >
                {u === "All" ? "All houses" : u}
              </button>
            ))}
          </div>
          <select
            aria-label="Medication round view"
            value={view}
            onChange={(e) => setView(e.target.value)}
          >
            <option>Awaiting encounter</option>
            <option>All current orders</option>
          </select>
        </div>
        <div className="round-queue">
          {shown.map((o) => {
            const r = state.residents.find((r) => r.id === o.residentId)!;
            const recorded = encounters(o.id);
            return (
              <div className="round-row" key={o.id}>
                <span className={`resident-monogram house-${r.unit}`}>
                  {initials(r.name)}
                </span>
                <div>
                  <h3>
                    {r.name}{" "}
                    <small>
                      {r.unit}/{r.room}
                    </small>
                  </h3>
                  <strong>
                    {o.medication} · {o.dose} · {o.route}
                  </strong>
                  <p>
                    {o.schedule} · Ref. {o.reference}
                  </p>
                  {recorded.length > 0 && (
                    <small className="round-recorded">
                      {recorded.length} encounter
                      {recorded.length > 1 ? "s" : ""} today ·{" "}
                      {recorded[0].answers.outcome}
                    </small>
                  )}
                </div>
                <button
                  onClick={() => {
                    onClose();
                    void start("medication", r.id, o.id);
                  }}
                >
                  Open pass <ArrowRight size={16} />
                </button>
              </div>
            );
          })}
          {!shown.length && (
            <div className="workbench-empty">
              <CheckCircle2 size={28} />
              <h3>
                {orders.length
                  ? "Every order has an encounter today."
                  : "No current orders for this selection."}
              </h3>
              <p>
                {orders.length
                  ? "Recorded outcomes include refused, held, and omitted. Review each record; this does not mean every dose was given."
                  : "Record an authorized order from Medication orders to populate this queue."}
              </p>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
