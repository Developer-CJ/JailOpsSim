import {
  MedicationRound,
  PersonPicker,
  PlacementPicker,
  ResidentWorkbench,
  ShiftBoard,
  initials,
} from "./CustodyWorkbench";
import { useEffect, useRef, useState } from "react";
import {
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  Maximize2,
  Minimize2,
  Download,
  Printer,
  CheckCircle2,
  ClipboardCheck,
  Fingerprint,
  HeartPulse,
  IdCard,
  Layers3,
  Plus,
  RotateCcw,
  ShieldCheck,
  Route,
  X,
} from "lucide-react";
import { useSimulation } from "./store";
import { Button, Field, Modal } from "./components";
import {
  questions,
  release,
  workflowChecks,
  workflowPaused,
} from "../shared/workflows";
import type {
  MedicationOrder,
  Workflow,
  WorkflowKind,
} from "../shared/workflows";
import type { Page } from "./model";
const paths = [
  {
    kind: "intake" as const,
    title: "Welcome & intake",
    tag: "01 / ADMISSIONS",
    detail: "From arrival to a considered placement. Every check, in order.",
    icon: ArrowDownLeft,
    color: "citrus",
  },
  {
    kind: "medication" as const,
    title: "Medication pass",
    tag: "02 / RESIDENT CARE",
    detail: "One person. One order. A clearly documented encounter.",
    icon: HeartPulse,
    color: "rose",
  },
  {
    kind: "custody" as const,
    title: "Custody handoff",
    tag: "03 / ACCOUNTABILITY",
    detail: "Know who is responsible, from departure to arrival.",
    icon: Route,
    color: "blue",
  },
  {
    kind: "release" as const,
    title: "Release & transition",
    tag: "04 / TRANSITIONS",
    detail: "Authority, identity, property, and a supported next step.",
    icon: ShieldCheck,
    color: "mint",
  },
];
type ReaderStatus = {
  fingerprintConfigured: boolean;
  bridgeUrl: string;
  cardMode: string;
  fingerprintStatus: string;
};
export function WorkflowDesk({
  navigate,
  initialResidentId,
}: {
  navigate: (page: Page, id?: string) => void;
  initialResidentId?: string;
}) {
  const { state, dispatch, user, pending } = useSimulation();
  const [selected, setSelected] = useState<string | null>(null),
    [device, setDevice] = useState(false),
    [order, setOrder] = useState(false),
    [filter, setFilter] = useState("All"),
    [round, setRound] = useState(false),
    [houseFocus, setHouseFocus] = useState("All");
  const records = state.workflows.records;
  const drafts = records.filter(
    (w) => w.status === "Draft" && w.owner === user.username,
  );
  const completed = records.filter((w) => w.status === "Completed");
  const current = records.find((w) => w.id === selected);
  const previousIds = useRef(new Set(records.map((w) => w.id)));
  const starting = useRef(false);
  useEffect(() => {
    if (starting.current) {
      const created = records.find(
        (w) => !previousIds.current.has(w.id) && w.owner === user.username,
      );
      if (created) {
        setSelected(created.id);
        starting.current = false;
      }
    }
    previousIds.current = new Set(records.map((w) => w.id));
  }, [records, user.username]);
  async function start(
    kind: WorkflowKind,
    residentId?: string,
    orderId?: string,
  ) {
    const existing = records.find(
      (w) =>
        w.owner === user.username &&
        w.status === "Draft" &&
        w.kind === kind &&
        residentId &&
        w.residentId === residentId &&
        (!orderId || w.answers.orderId === orderId),
    );
    if (existing) {
      setSelected(existing.id);
      return;
    }
    starting.current = true;
    if (!(await dispatch({ type: "workflowStart", kind, residentId, orderId })))
      starting.current = false;
  }
  return (
    <div className="workflow-desk">
      <div className="desk-kicker">
        <span>
          <i /> CUSTODY OPERATIONS / WORKFLOW DESK
        </span>
        <span>
          JAILOPS {release.version} · {release.storageLabel}
        </span>
      </div>
      <div className="shift-command-strip">
        <button
          onClick={() =>
            document
              .getElementById("resident-workbench")
              ?.scrollIntoView({ behavior: "smooth" })
          }
        >
          <span>IN YOUR CARE</span>
          <strong>
            {state.residents.length}
            <small> residents</small>
          </strong>
        </button>
        <button
          onClick={() =>
            document
              .getElementById("shift-pathway-board")
              ?.scrollIntoView({ behavior: "smooth" })
          }
        >
          <span>YOUR OPEN PATHWAYS</span>
          <strong>
            {drafts.length}
            <small> in progress</small>
          </strong>
        </button>
        <button
          onClick={() =>
            document
              .getElementById("shift-pathway-board")
              ?.scrollIntoView({ behavior: "smooth" })
          }
        >
          <span>NEEDS A DECISION</span>
          <strong>
            {drafts.filter(workflowPaused).length}
            <small> paused</small>
          </strong>
        </button>
        <button onClick={() => setRound(true)}>
          <span>CARE WORKSPACE</span>
          <strong>
            <HeartPulse size={20} /> Medication round <ArrowUpRight size={16} />
          </strong>
        </button>
      </div>
      <section className="desk-hero">
        <div>
          <div className="desk-label">THE NEXT RIGHT STEP</div>
          <h1>
            Your shift.
            <br />
            <em>In motion.</em>
          </h1>
          <p>
            See the person. Know the context. Take the next step.
            <br />
            Open a custody record or start a guided pathway.
          </p>
          <div className="hero-actions">
            <button onClick={() => void start("intake")} disabled={pending}>
              Begin an intake <ArrowUpRight size={19} />
            </button>
            <button onClick={() => setDevice(true)}>
              <Fingerprint size={19} /> Verification devices
            </button>
          </div>
        </div>
        <div className="custody-orbit" aria-label="Current custody overview">
          <div className="orbit-top">
            <Layers3 size={21} />
            <span>FACILITY PULSE</span>
            <i />
          </div>
          <div className="pulse-number">
            {state.residents.length}
            <span>residents in care</span>
          </div>
          <div className="pulse-track">
            {["A1", "A2", "B1", "B2"].map((unit) => (
              <button
                key={unit}
                onClick={() => {
                  setHouseFocus(unit);
                  document
                    .getElementById("resident-workbench")
                    ?.scrollIntoView({ behavior: "smooth" });
                }}
                aria-label={`Browse house ${unit}`}
              >
                <span>{unit}</span>
                <div>
                  <i
                    style={{
                      width: `${(state.residents.filter((r) => r.unit === unit).length / 16) * 100}%`,
                    }}
                  />
                </div>
                <b>
                  {state.residents.filter((r) => r.unit === unit).length}
                  <small>/16</small>
                </b>
              </button>
            ))}
          </div>
          <button onClick={() => navigate("facility-view")}>
            Open the facility <ArrowUpRight size={16} />
          </button>
        </div>
      </section>
      <div className="desk-section-title">
        <div>
          <span className="desk-label">START WITH INTENTION</span>
          <h2>What needs to happen?</h2>
        </div>
        <span>Four pathways. Connected records.</span>
      </div>
      <div className="path-grid">
        {paths.map((p) => (
          <button
            className={`path-card ${p.color}`}
            key={p.kind}
            onClick={() => void start(p.kind)}
            disabled={pending}
          >
            <div className="path-top">
              <p.icon size={26} />
              <span>{p.tag}</span>
            </div>
            <h3>{p.title}</h3>
            <p>{p.detail}</p>
            <div className="path-bottom">
              <span>{questions(p.kind).length} guided checks</span>
              <ArrowUpRight size={24} />
            </div>
          </button>
        ))}
      </div>
      <div id="resident-workbench">
        <ResidentWorkbench
          start={start}
          navigate={navigate}
          initialResidentId={initialResidentId}
          houseFocus={houseFocus}
          onHouseChange={setHouseFocus}
        />
      </div>
      <div id="shift-pathway-board">
        <ShiftBoard open={setSelected} />
      </div>
      <div className="desk-workbench">
        <section className="desk-queue">
          <div className="desk-section-title">
            <div>
              <span className="desk-label">PICK UP WHERE YOU LEFT OFF</span>
              <h2>
                Your work in progress <b>{drafts.length}</b>
              </h2>
            </div>
          </div>
          {drafts.length === 0 ? (
            <div className="desk-empty">
              <CheckCircle2 size={30} />
              <strong>A clear desk.</strong>
              <p>
                Your saved workflows will appear here. Each completed answer is
                saved to the server.
              </p>
            </div>
          ) : (
            drafts.map((w) => (
              <button
                className="draft-row"
                key={w.id}
                onClick={() => setSelected(w.id)}
              >
                <span
                  className={`draft-icon ${paths.find((p) => p.kind === w.kind)!.color}`}
                >
                  <ClipboardCheck size={21} />
                </span>
                <span>
                  <strong>{paths.find((p) => p.kind === w.kind)!.title}</strong>
                  <small>
                    {w.answers.name ||
                      state.residents.find((r) => r.id === w.residentId)
                        ?.name ||
                      "Awaiting person details"}{" "}
                    · {w.step}/{questions(w.kind).length} checks
                  </small>
                  <span className="mini-progress">
                    <i
                      style={{
                        width: `${(w.step / questions(w.kind).length) * 100}%`,
                      }}
                    />
                  </span>
                </span>
                <ArrowRight size={20} />
              </button>
            ))
          )}
        </section>
        <aside className="desk-notes">
          <span className="desk-label">THE STANDARD OF CARE</span>
          <h2>
            Slow down at
            <br />
            the critical checks.
          </h2>
          <p>
            Identity. Authority. Handover.
            <br />A completed screen is a record of what you checked. Read the
            details before you commit.
          </p>
          <button onClick={() => navigate("residents")}>
            Resident directory <ArrowUpRight size={17} />
          </button>
          <button onClick={() => navigate("reports")}>
            Open the audit trail <ArrowUpRight size={17} />
          </button>
          <button onClick={() => setOrder(true)}>
            Medication orders <ArrowUpRight size={17} />
          </button>
        </aside>
      </div>
      <section className="desk-ledger">
        <div className="desk-section-title">
          <div>
            <span className="desk-label">A CONTINUOUS RECORD</span>
            <h2>Completed encounters</h2>
          </div>
          <select
            aria-label="Filter completed workflows"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            {["All", ...paths.map((p) => p.kind)].map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </div>
        {completed.filter((w) => filter === "All" || w.kind === filter)
          .length === 0 ? (
          <p className="ledger-empty">No completed encounters in this view.</p>
        ) : (
          completed
            .filter((w) => filter === "All" || w.kind === filter)
            .slice(0, 20)
            .map((w) => (
              <button
                key={w.id}
                className="ledger-row"
                onClick={() => setSelected(w.id)}
              >
                <CheckCircle2 size={20} />
                <strong>{paths.find((p) => p.kind === w.kind)!.title}</strong>
                <span>
                  {w.answers.name ||
                    state.residents.find((r) => r.id === w.residentId)?.name ||
                    state.discharged.find((r) => r.id === w.residentId)?.name ||
                    w.residentId}
                </span>
                <span>{w.verification?.method}</span>
                <time>{new Date(w.updated).toLocaleString()}</time>
                <ArrowUpRight size={16} />
              </button>
            ))
        )}
      </section>
      <footer className="desk-footer">
        JAILOPS / JUVENILE CUSTODY WORKSPACE{" "}
        <span>
          Control panels and generated feeds remain demonstration sources.
        </span>
      </footer>
      {current && (
        <Interview
          key={current.id}
          workflow={current}
          onClose={() => setSelected(null)}
          onRound={() => {
            setSelected(null);
            setRound(true);
          }}
        />
      )}
      {round && (
        <MedicationRound start={start} onClose={() => setRound(false)} />
      )}
      {device && <Devices onClose={() => setDevice(false)} />}
      {order && <Orders onClose={() => setOrder(false)} />}
    </div>
  );
}
function Interview({
  workflow: w,
  onClose,
  onRound,
}: {
  workflow: Workflow;
  onClose: () => void;
  onRound: () => void;
}) {
  const { state, dispatch, pending, user } = useSimulation();
  const qs = questions(w.kind),
    q = qs[w.step],
    path = paths.find((p) => p.kind === w.kind)!;
  const [value, setValue] = useState(w.draft?.value || ""),
    [confirmed, setConfirmed] = useState(false),
    [checks, setChecks] = useState<string[]>(w.draft?.checks || []),
    [immersive, setImmersive] = useState(false);
  const questionRef = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    setValue(q && w.draft?.key === q.key ? w.draft.value : "");
    setChecks(q && w.draft?.key === q.key ? w.draft.checks || [] : []);
    setConfirmed(false);
    questionRef.current?.focus();
  }, [w.step]);
  useEffect(() => {
    const choose = (event: KeyboardEvent) => {
      if (
        !q?.options ||
        event.ctrlKey ||
        event.metaKey ||
        event.altKey ||
        /^(INPUT|TEXTAREA|SELECT)$/.test((event.target as HTMLElement)?.tagName)
      )
        return;
      const choices = q.options.filter(
        (option) =>
          !(
            w.kind === "medication" &&
            q.key === "outcome" &&
            w.answers.rights !== "All checks complete" &&
            option === "Given"
          ),
      );
      const index = event.key.toUpperCase().charCodeAt(0) - 65;
      if (event.key.length === 1 && index >= 0 && index < choices.length) {
        event.preventDefault();
        setValue(choices[index]);
      }
    };
    document.addEventListener("keydown", choose);
    return () => document.removeEventListener("keydown", choose);
  }, [q, w.kind, w.answers.rights]);
  const resident =
    (w.status === "Completed" ? w.residentSnapshot : undefined) ||
    state.residents.find((r) => r.id === w.residentId) ||
    state.discharged.find((r) => r.id === w.residentId);
  const today = new Date().toISOString().slice(0, 10);
  const order = state.workflows.orders.find((o) => o.id === w.answers.orderId);
  const blocked =
    w.answers.screening === "Concern identified · hold for assessment" ||
    w.answers.holds === "Hold unresolved · stop release" ||
    w.answers.property === "Unresolved · stop release";
  const requiredChecks = q ? workflowChecks(w.kind, q.key) : [];
  const missingChecks = requiredChecks.some((c) => !checks.includes(c.id));
  async function saveClose() {
    if (pending) return;
    if (
      w.status === "Draft" &&
      q &&
      q.input !== "identity" &&
      (value !== (w.draft?.value || "") || checks.length)
    ) {
      if (
        !(await dispatch({
          type: "workflowDraft",
          id: w.id,
          key: q.key,
          value,
          checks: requiredChecks.length ? checks : undefined,
        }))
      )
        return;
    }
    onClose();
  }
  function exportRecord() {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            application: "JailOps",
            version: release.version,
            resident: resident
              ? { id: resident.id, name: resident.name }
              : null,
            encounter: w,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob),
      link = document.createElement("a");
    link.href = url;
    link.download = `JailOps-encounter-${w.id}.json`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function answer(v = value) {
    if (v.trim())
      await dispatch({
        type: "workflowAnswer",
        id: w.id,
        key: q.key,
        value: v,
        checks: requiredChecks.length ? checks : undefined,
      });
  }
  return (
    <Modal
      wide
      title={path.title}
      subtitle={`${w.id.slice(0, 8).toUpperCase()} · ${w.status} · ${w.owner}`}
      onClose={() => {
        void saveClose();
      }}
      className={`interview-modal ${immersive ? "immersive" : ""}`}
    >
      <div className={`interview ${path.color}`}>
        <aside className="interview-rail">
          <path.icon size={34} />
          <h3>
            One step.
            <br />
            Full attention.
          </h3>
          <p>{resident?.name || w.answers.name || "Start with the person."}</p>
          <ol>
            {qs.map((step, i) => (
              <li
                key={step.key}
                className={i === w.step ? "current" : i < w.step ? "done" : ""}
              >
                <button
                  type="button"
                  disabled={pending || w.status !== "Draft" || i >= w.step}
                  aria-label={`Revisit ${step.key}`}
                  onClick={() =>
                    void dispatch({
                      type: "workflowRevisit",
                      id: w.id,
                      step: i,
                    })
                  }
                >
                  <span>
                    {i < w.step ? (
                      <Check size={12} />
                    ) : (
                      String(i + 1).padStart(2, "0")
                    )}
                  </span>
                  {step.key === "identity"
                    ? "Verify identity"
                    : step.key === "residentId"
                      ? "Select resident"
                      : step.title.replace(/\?$/, "")}
                </button>
              </li>
            ))}
          </ol>
          <small>
            Answers save after Continue.
            <br />
            Close and resume from your desk.
          </small>
        </aside>
        <div className="interview-main">
          <div className="interview-context">
            <span
              className={`resident-monogram house-${resident?.unit || "INT"}`}
            >
              {initials(resident?.name || w.answers.name || "New arrival")}
            </span>
            <div>
              <strong>
                {resident?.name || w.answers.name || "New arrival"}
              </strong>
              <small>
                {resident
                  ? `${resident.id} · ${resident.unit}/${resident.room}`
                  : "Admission record in progress"}
              </small>
            </div>
            <button
              type="button"
              aria-label={immersive ? "Exit focus view" : "Expand workflow"}
              onClick={() => setImmersive((v) => !v)}
            >
              {immersive ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>
          </div>
          <div className="interview-progress">
            <span>
              {w.status === "Completed"
                ? "RECORD CLOSED"
                : q
                  ? `CHECK ${String(w.step + 1).padStart(2, "0")} / ${qs.length}`
                  : "FINAL REVIEW"}
            </span>
            <span>{Math.round((w.step / qs.length) * 100)}%</span>
            <div>
              <i style={{ width: `${(w.step / qs.length) * 100}%` }} />
            </div>
          </div>
          {blocked && w.status === "Draft" ? (
            <div className="question-panel hold-panel">
              <ShieldCheck size={38} />
              <h2>Pause this pathway.</h2>
              <p>
                An unresolved welfare concern, custody hold, or handover
                requirement needs attention. The workflow is saved. Resolve it
                using the authoritative process before changing the response and
                continuing.
              </p>
              <Button onClick={onClose}>Save & return to desk</Button>
            </div>
          ) : q && w.status === "Draft" ? (
            <form
              key={q.key}
              className="question-panel"
              onSubmit={(e) => {
                e.preventDefault();
                void answer();
              }}
            >
              <h2 ref={questionRef} tabIndex={-1}>
                {q.title}
              </h2>
              <p>{q.hint}</p>
              {q.input === "identity" ? (
                <Identity w={w} onVerified={(v) => void answer(v)} />
              ) : q.options ? (
                <>
                  {requiredChecks.length > 0 && (
                    <div className="verification-checklist">
                      <div className="checklist-heading">
                        <span>VERIFY EACH ITEM</span>
                        <strong>
                          {checks.length}/{requiredChecks.length}
                        </strong>
                      </div>
                      {requiredChecks.map((check) => (
                        <label
                          className={checks.includes(check.id) ? "checked" : ""}
                          key={check.id}
                        >
                          <input
                            type="checkbox"
                            checked={checks.includes(check.id)}
                            onChange={(e) =>
                              setChecks((list) =>
                                e.target.checked
                                  ? [...list, check.id]
                                  : list.filter((id) => id !== check.id),
                              )
                            }
                          />
                          <span className="checkmark">
                            <Check size={13} />
                          </span>
                          <span>
                            <strong>{check.title}</strong>
                            <small>{check.detail}</small>
                          </span>
                        </label>
                      ))}
                    </div>
                  )}
                  <div className="answer-choices">
                    {q.options
                      .filter(
                        (option) =>
                          !(
                            w.kind === "medication" &&
                            q.key === "outcome" &&
                            w.answers.rights !== "All checks complete" &&
                            option === "Given"
                          ),
                      )
                      .map((option, i) => (
                        <button
                          type="button"
                          aria-pressed={value === option}
                          key={option}
                          onClick={() => setValue(option)}
                        >
                          <kbd>{String.fromCharCode(65 + i)}</kbd>
                          {option}
                          <span>
                            {value === option ? (
                              <CheckCircle2 size={20} />
                            ) : (
                              <span className="choice-circle" />
                            )}
                          </span>
                        </button>
                      ))}
                  </div>
                </>
              ) : q.input === "resident" ? (
                <PersonPicker value={value} onChange={setValue} />
              ) : q.input === "room" ? (
                <PlacementPicker value={value} onChange={setValue} />
              ) : q.input === "order" ? (
                <>
                  <select
                    required
                    aria-label="Authorized order"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                  >
                    <option value="">Select a current order…</option>
                    {state.workflows.orders
                      .filter(
                        (o) =>
                          o.residentId === w.residentId &&
                          o.active &&
                          o.starts <= today &&
                          o.ends >= today,
                      )
                      .map((o) => (
                        <option key={o.id} value={o.id}>
                          {o.medication} · {o.dose} · {o.route} · {o.schedule}
                        </option>
                      ))}
                  </select>
                  <small>
                    No order? Save this workflow and open Medication orders on
                    the desk.
                  </small>
                </>
              ) : q.input === "number" ? (
                <input
                  aria-label="Age"
                  type="number"
                  min={12}
                  max={20}
                  required
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                />
              ) : (
                <textarea
                  aria-label={q.title}
                  required
                  maxLength={
                    ["plan", "caseManager"].includes(q.key)
                      ? 100
                      : q.key === "name"
                        ? 70
                        : 1000
                  }
                  rows={3}
                  placeholder="Type your answer here…"
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                />
              )}
              {q.input !== "identity" && (
                <div className="question-actions">
                  <button
                    className="question-continue"
                    type="submit"
                    disabled={
                      !value.trim() ||
                      pending ||
                      (requiredChecks.length > 0 &&
                        value === q.options?.[0] &&
                        missingChecks)
                    }
                  >
                    Continue <ArrowRight size={19} />
                  </button>
                  <span>Saved when you continue</span>
                </div>
              )}
              {q.key === "rights" && order && (
                <div className="order-reference">
                  <strong>
                    {order.medication} · {order.dose} · {order.route}
                  </strong>
                  <span>
                    {order.schedule} / {order.prescriber} / Ref.{" "}
                    {order.reference}
                  </span>
                </div>
              )}
            </form>
          ) : (
            <div className="question-panel review-panel">
              <h2 ref={questionRef} tabIndex={-1}>
                {w.status === "Completed"
                  ? "Encounter recorded."
                  : "Pause. Review. Confirm."}
              </h2>
              <p>
                {w.status === "Completed"
                  ? `Recorded by ${w.owner} at ${new Date(w.completed!).toLocaleString()}.`
                  : "Read each answer against the source documents and the person in your care."}
              </p>
              <dl>
                {qs.map((step, stepIndex) => (
                  <div key={step.key}>
                    <dt>
                      {step.title}
                      {w.status === "Draft" && (
                        <button
                          type="button"
                          disabled={pending}
                          onClick={() =>
                            void dispatch({
                              type: "workflowRevisit",
                              id: w.id,
                              step: stepIndex,
                            })
                          }
                        >
                          Edit
                        </button>
                      )}
                    </dt>
                    <dd>
                      {step.key === "residentId"
                        ? resident?.name || w.answers[step.key]
                        : step.key === "orderId"
                          ? `${order?.medication} · ${order?.dose} · ${order?.route}`
                          : w.answers[step.key]}
                    </dd>
                    {w.evidence?.[step.key]?.length ? (
                      <div className="review-checks">
                        {workflowChecks(w.kind, step.key)
                          .filter((c) => w.evidence![step.key].includes(c.id))
                          .map((c) => (
                            <span key={c.id}>
                              <Check size={11} />
                              {c.title}
                            </span>
                          ))}
                      </div>
                    ) : null}
                  </div>
                ))}
              </dl>
              {w.status === "Draft" && (
                <>
                  <label className="review-confirm">
                    <input
                      type="checkbox"
                      checked={confirmed}
                      onChange={(e) => setConfirmed(e.target.checked)}
                    />
                    <span>
                      I, {user.username}, confirm this record reflects the
                      checks and actions I performed.
                    </span>
                  </label>
                  <button
                    className="question-continue"
                    disabled={!confirmed || pending}
                    onClick={() =>
                      void dispatch({ type: "workflowComplete", id: w.id })
                    }
                  >
                    Commit{" "}
                    {w.kind === "release"
                      ? "release"
                      : w.kind === "intake"
                        ? "admission"
                        : "encounter"}{" "}
                    <CheckCircle2 size={19} />
                  </button>
                </>
              )}
              {w.status === "Completed" && (
                <div className="completed-actions">
                  <div className="receipt-stamp">
                    <CheckCircle2 size={29} />
                    <span>
                      RECORDED · {w.id.slice(0, 8).toUpperCase()}
                      <small>Audit entry saved with the encounter.</small>
                    </span>
                  </div>
                  <Button variant="primary" onClick={onClose}>
                    Return to desk <ArrowRight size={17} />
                  </Button>
                  {w.kind === "medication" && (
                    <Button onClick={onRound}>
                      Continue medication round <HeartPulse size={17} />
                    </Button>
                  )}
                  <Button onClick={exportRecord}>
                    <Download size={16} />
                    Export encounter
                  </Button>
                  <Button onClick={() => window.print()}>
                    <Printer size={16} />
                    Print record
                  </Button>
                </div>
              )}
            </div>
          )}
          {w.status === "Draft" && (
            <div className="interview-bottom">
              <button
                disabled={pending || w.step === 0}
                onClick={() =>
                  void dispatch({ type: "workflowBack", id: w.id })
                }
              >
                <RotateCcw size={15} /> Previous question
              </button>
              <button
                disabled={pending}
                onClick={async () => {
                  if (await dispatch({ type: "workflowCancel", id: w.id }))
                    onClose();
                }}
              >
                <X size={15} /> Cancel workflow
              </button>
              <button disabled={pending} onClick={() => void saveClose()}>
                Save & close <ArrowUpRight size={15} />
              </button>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
function Identity({
  w,
  onVerified,
}: {
  w: Workflow;
  onVerified: (proof: string) => void;
}) {
  const { readerRequest } = useSimulation();
  const [method, setMethod] = useState("manual"),
    [manual, setManual] = useState(""),
    [card, setCard] = useState(""),
    [status, setStatus] = useState<ReaderStatus | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    readerRequest<ReaderStatus>("")
      .then(setStatus)
      .catch((e) => setError(e.message));
  }, [readerRequest]);
  async function verify(kind: "card" | "fingerprint") {
    setBusy(true);
    setError("");
    try {
      let proof: string;
      if (kind === "card") {
        const result = await readerRequest<{ proof: string }>("/card", {
          workflowId: w.id,
          credential: card,
        });
        proof = result.proof;
        setCard("");
      } else {
        const challenge = await readerRequest<{
          nonce: string;
          subject: string;
          expires: number;
          operator: string;
        }>("/challenge", { workflowId: w.id });
        const response = await fetch(`${status!.bridgeUrl}/verify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(challenge),
          signal: AbortSignal.timeout(45000),
        });
        if (!response.ok)
          throw new Error(
            "The workstation adapter did not return a successful match.",
          );
        const assertion = await response.json();
        proof = (
          await readerRequest<{ proof: string }>("/fingerprint", {
            nonce: challenge.nonce,
            subject: challenge.subject,
            signature: assertion.signature,
            residentCheck: manual.trim(),
          })
        ).proof;
      }
      onVerified(proof);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Reader verification failed.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="identity-check">
      <div className="identity-tabs">
        {[
          { id: "manual", label: "Staff check", icon: ShieldCheck },
          { id: "card", label: "Facility card", icon: IdCard },
          { id: "fingerprint", label: "Fingerprint", icon: Fingerprint },
        ].map((m) => (
          <button
            type="button"
            key={m.id}
            aria-pressed={method === m.id}
            onClick={() => {
              setMethod(m.id);
              setError("");
            }}
          >
            <m.icon size={19} />
            {m.label}
          </button>
        ))}
      </div>
      {method === "manual" ? (
        <>
          <label className="field">
            <span>Two identifiers checked and source reference</span>
            <textarea
              value={manual}
              onChange={(e) => setManual(e.target.value)}
              maxLength={900}
              placeholder="Record the identifiers checked and document or wristband reference. Avoid copying sensitive identity numbers."
            />
          </label>
          <button
            type="button"
            className="question-continue"
            disabled={manual.trim().length < 12 || busy}
            onClick={() => onVerified(`manual:${manual.trim()}`)}
          >
            Record manual attestation <ShieldCheck size={18} />
          </button>
          <small>
            This does not record a biometric or device verification.
          </small>
        </>
      ) : method === "card" ? (
        <>
          <p>
            Use a facility-issued identifier enrolled under Verification
            devices. Configure your reader for keyboard output with Enter.
            Payment card data is rejected.
          </p>
          <input
            type="password"
            aria-label="Scan facility identifier"
            autoComplete="off"
            value={card}
            maxLength={120}
            onChange={(e) => setCard(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                void verify("card");
              }
            }}
          />
          <button
            type="button"
            className="question-continue"
            disabled={busy || !card}
            onClick={() => void verify("card")}
          >
            {busy ? "Checking…" : "Verify identifier"} <IdCard size={18} />
          </button>
        </>
      ) : (
        <>
          <label className="field">
            <span>Resident identifiers and source checked</span>
            <textarea
              aria-label="Resident check for staff fingerprint"
              value={manual}
              maxLength={900}
              onChange={(e) => setManual(e.target.value)}
              placeholder="Record the two resident identifiers you checked."
            />
          </label>
          <div className="scanner-state">
            <Fingerprint size={64} />
            <strong>
              {status?.fingerprintStatus || "Checking configuration…"}
            </strong>
            <p>DigitalPersona U.are.U 4500 · existing WBF driver</p>
            <button
              type="button"
              className="question-continue"
              disabled={
                !status?.fingerprintConfigured ||
                busy ||
                manual.trim().length < 12
              }
              onClick={() => void verify("fingerprint")}
            >
              {busy ? "Waiting for a match…" : "Verify staff fingerprint"}
            </button>
            <small>
              Verifies the enrolled Windows staff identity. Resident identity is
              recorded through your two-identifier check.
            </small>
          </div>
        </>
      )}
      {error && (
        <p role="alert" className="verification-error">
          {error}
        </p>
      )}
    </div>
  );
}
function Devices({ onClose }: { onClose: () => void }) {
  const { readerRequest, state, user } = useSimulation();
  const [status, setStatus] = useState<ReaderStatus | null>(null),
    [person, setPerson] = useState(""),
    [card, setCard] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    readerRequest<ReaderStatus>("")
      .then(setStatus)
      .catch((e) => setMessage(e.message));
  }, [readerRequest]);
  async function enroll(revoke = false) {
    setBusy(true);
    try {
      await readerRequest(
        revoke ? "/revoke" : "/enroll",
        revoke
          ? { residentId: person }
          : { residentId: person, credential: card },
      );
      setCard("");
      setMessage(
        revoke ? "Identifiers revoked." : "Facility identifier enrolled.",
      );
    } catch (e) {
      setMessage((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      wide
      title="Verification devices"
      subtitle="Workstation hardware & identity enrollment"
      onClose={onClose}
    >
      <div className="device-panel">
        <section>
          <Fingerprint size={36} />
          <h3>U.are.U 4500 / WBF</h3>
          <p>{status?.fingerprintStatus || "Loading status…"}</p>
          <p>
            Keep your existing WBF driver. The Windows bridge uses Windows
            Biometric Framework to verify the enrolled Windows staff user.
            Resident matching needs a separate enrollment and matching system.
          </p>
          <code>Workstation: 127.0.0.1:17443</code>
          <small>
            See docs/DEVICE_INTEGRATION.md for the signed adapter contract. The
            included .NET bridge must be built and configured on the reader
            workstation. Windows biometric enrollment is required.
          </small>
        </section>
        <section>
          <IdCard size={36} />
          <h3>MSR213U-12AUBNR</h3>
          <p>{status?.cardMode || "Loading status…"}</p>
          <p>
            Configure the MSR utility for keyboard output and an Enter suffix.
            Enroll facility identifiers only; magnetic payment-card track data
            is not accepted.
          </p>
          {user.role === "admin" ? (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void enroll();
              }}
            >
              <Field label="Resident">
                <select
                  required
                  value={person}
                  onChange={(e) => setPerson(e.target.value)}
                >
                  <option value="">Choose resident…</option>
                  {state.residents.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} · {r.id}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Scan facility identifier">
                <input
                  required
                  type="password"
                  autoComplete="off"
                  value={card}
                  maxLength={120}
                  onChange={(e) => setCard(e.target.value)}
                />
              </Field>
              <div className="device-actions">
                <Button
                  type="submit"
                  variant="primary"
                  disabled={busy || !person || !card}
                >
                  Enroll identifier
                </Button>
                <Button
                  disabled={busy || !person}
                  onClick={() => void enroll(true)}
                >
                  Revoke identifiers
                </Button>
              </div>
            </form>
          ) : (
            <p>
              Ask an administrator to enroll or revoke a facility identifier.
            </p>
          )}
        </section>
        {message && <p role="status">{message}</p>}
      </div>
    </Modal>
  );
}
function Orders({ onClose }: { onClose: () => void }) {
  const { state, dispatch, user, pending } = useSimulation();
  const empty = {
    residentId: "",
    medication: "",
    dose: "",
    route: "",
    schedule: "",
    prescriber: "",
    reference: "",
    starts: new Date().toISOString().slice(0, 10),
    ends: new Date().toISOString().slice(0, 10),
  };
  const [order, setOrder] = useState(empty),
    [adding, setAdding] = useState(false);
  const fields: { key: keyof typeof empty; label: string; type?: string }[] = [
    { key: "medication", label: "Medication as ordered" },
    { key: "dose", label: "Dose as ordered" },
    { key: "route", label: "Route as ordered" },
    { key: "schedule", label: "Scheduled time / instructions" },
    { key: "prescriber", label: "Prescriber" },
    { key: "reference", label: "Authoritative order reference" },
    { key: "starts", label: "Start date", type: "date" },
    { key: "ends", label: "End date", type: "date" },
  ];
  return (
    <Modal
      wide
      title="Medication orders"
      subtitle="Transcribe authorized instructions. No dose calculation or prescribing."
      onClose={onClose}
    >
      <div className="orders-panel">
        {user.role === "admin" && (
          <Button onClick={() => setAdding((v) => !v)}>
            <Plus size={16} />
            {adding ? "Close form" : "Record an authorized order"}
          </Button>
        )}
        {adding && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (await dispatch({ type: "medicationOrder", order })) {
                setOrder(empty);
                setAdding(false);
              }
            }}
          >
            <Field label="Resident">
              <select
                required
                value={order.residentId}
                onChange={(e) =>
                  setOrder({ ...order, residentId: e.target.value })
                }
              >
                <option value="">Choose resident…</option>
                {state.residents.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} · {r.id}
                  </option>
                ))}
              </select>
            </Field>
            <div className="order-fields">
              {fields.map((f) => (
                <Field key={f.key} label={f.label}>
                  <input
                    required
                    type={f.type || "text"}
                    maxLength={1000}
                    value={order[f.key]}
                    onChange={(e) =>
                      setOrder({ ...order, [f.key]: e.target.value })
                    }
                  />
                </Field>
              ))}
            </div>
            <Button type="submit" variant="primary" disabled={pending}>
              Save authorized order
            </Button>
          </form>
        )}
        {state.workflows.orders.length === 0 ? (
          <div className="desk-empty">
            <HeartPulse size={30} />
            <strong>No medication orders.</strong>
            <p>Add an authorized order before starting a medication pass.</p>
          </div>
        ) : (
          state.workflows.orders.map((o: MedicationOrder) => (
            <div className="order-item" key={o.id}>
              <div>
                <strong>
                  {o.medication} · {o.dose} · {o.route}
                </strong>
                <p>
                  {state.residents.find((r) => r.id === o.residentId)?.name ||
                    o.residentId}{" "}
                  / {o.schedule}
                </p>
                <small>
                  {o.prescriber} · Ref. {o.reference} · {o.starts} → {o.ends} ·{" "}
                  {o.active ? "Active" : "Discontinued"}
                </small>
              </div>
              {o.active && user.role === "admin" && (
                <Button
                  disabled={pending}
                  onClick={() =>
                    void dispatch({ type: "medicationOrderStop", id: o.id })
                  }
                >
                  Discontinue
                </Button>
              )}
            </div>
          ))
        )}
      </div>
    </Modal>
  );
}
