using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;

// Windows workstation process. Uses the installed WBF driver and the signed-in
// Windows user's enrolled fingerprint; no fingerprint images/templates leave WBF.
var builder = WebApplication.CreateBuilder(args);
builder.Logging.ClearProviders(); // Never log assertions, identifiers, or request bodies.
builder.WebHost.UseUrls("http://127.0.0.1:17443");
var origin = Environment.GetEnvironmentVariable("JAILOPS_ORIGIN") ?? "";
var appOperator = Environment.GetEnvironmentVariable("JAILOPS_OPERATOR") ?? "";
var key = Environment.GetEnvironmentVariable("FINGERPRINT_BRIDGE_KEY") ?? "";
if (!Uri.TryCreate(origin, UriKind.Absolute, out var allowed) ||
    (allowed.Scheme != "https" && !allowed.IsLoopback) ||
    allowed.GetLeftPart(UriPartial.Authority) != origin ||
    appOperator.Length == 0 || key.Length < 32)
    throw new InvalidOperationException("Set an exact JAILOPS_ORIGIN, JAILOPS_OPERATOR, and a secret FINGERPRINT_BRIDGE_KEY of at least 32 characters.");
var app = builder.Build();
var gate = new SemaphoreSlim(1, 1);
var used = new HashSet<string>();
app.Use(async (context, next) => {
    if (context.Request.Headers.Origin.ToString() != origin) { context.Response.StatusCode = 403; return; }
    context.Response.Headers.AccessControlAllowOrigin = origin;
    context.Response.Headers.Vary = "Origin";
    context.Response.Headers.CacheControl = "no-store";
    if (context.Request.Method == "OPTIONS") {
        context.Response.Headers.AccessControlAllowMethods = "POST";
        context.Response.Headers.AccessControlAllowHeaders = "Content-Type";
        context.Response.Headers["Access-Control-Allow-Private-Network"] = "true";
        context.Response.StatusCode = 204; return;
    }
    await next();
});
app.MapPost("/verify", async (Challenge c) => {
    if (c.Operator != appOperator || c.Nonce.Length != 64 || !c.Nonce.All(Uri.IsHexDigit) ||
        c.Subject.Length is < 1 or > 200 || c.Subject.Contains('\n') ||
        c.Expires < DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() ||
        c.Expires > DateTimeOffset.UtcNow.AddSeconds(65).ToUnixTimeMilliseconds())
        return Results.BadRequest(new { error = "Challenge invalid or expired." });
    if (!await gate.WaitAsync(0)) return Results.Conflict(new { error = "Reader already in use." });
    try {
        if (!used.Add(c.Nonce)) return Results.Conflict(new { error = "Challenge already used." });
        if (used.Count > 10000) return Results.Problem("Restart the workstation bridge to renew the nonce cache.");
        var matched = await Task.Run(Wbf.VerifyCurrentUser);
        if (!matched || c.Expires < DateTimeOffset.UtcNow.ToUnixTimeMilliseconds())
            return Results.Json(new { error = "No matching staff fingerprint, or the challenge expired." }, statusCode: 409);
        var message = $"{c.Nonce}\n{c.Subject}\n{c.Operator}\nstaff-wbf-matched";
        var signature = Convert.ToHexString(HMACSHA256.HashData(Encoding.UTF8.GetBytes(key), Encoding.UTF8.GetBytes(message))).ToLowerInvariant();
        return Results.Ok(new { signature });
    } catch (Exception) {
        return Results.Json(new { error = "WBF verification unavailable. Check Windows biometric enrollment, service, and device access." }, statusCode: 503);
    } finally { gate.Release(); }
});
Console.WriteLine("JailOps WBF bridge listening on loopback port 17443. Keep this workstation window running.");
await app.RunAsync();
record Challenge(string Nonce, string Subject, long Expires, string Operator);
static class Wbf {
    [StructLayout(LayoutKind.Sequential)]
    unsafe struct Identity { public uint Type; public uint Size; public fixed byte Sid[68]; }
    [DllImport("winbio.dll")] static extern int WinBioOpenSession(uint factor, uint pool, uint flags, IntPtr units, nuint count, IntPtr database, out uint session);
    [DllImport("winbio.dll")] static extern unsafe int WinBioVerify(uint session, ref Identity identity, byte subtype, out uint unit, out byte match, out uint rejectDetail);
    [DllImport("winbio.dll")] static extern int WinBioCloseSession(uint session);
    [DllImport("winbio.dll")] static extern int WinBioCancel(uint session);
    public static unsafe bool VerifyCurrentUser() {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException();
        var sid = WindowsIdentity.GetCurrent().User ?? throw new InvalidOperationException();
        var bytes = new byte[sid.BinaryLength]; sid.GetBinaryForm(bytes, 0);
        if (bytes.Length > 68) throw new InvalidOperationException();
        var identity = new Identity { Type = 3, Size = (uint)bytes.Length }; // WINBIO_ID_TYPE_SID
        for (var i = 0; i < bytes.Length; i++) identity.Sid[i] = bytes[i];
        // WINBIO_TYPE_FINGERPRINT / WINBIO_POOL_SYSTEM / WINBIO_FLAG_DEFAULT.
        var hr = WinBioOpenSession(8, 1, 0, IntPtr.Zero, 0, IntPtr.Zero, out var session);
        Marshal.ThrowExceptionForHR(hr);
        try { using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(45)); using var cancellation = timeout.Token.Register(() => WinBioCancel(session)); hr = WinBioVerify(session, ref identity, 0xff, out _, out var match, out _); return hr >= 0 && match != 0; }
        finally { WinBioCloseSession(session); }
    }
}
