import { z } from "zod";
import { randomUUID } from "node:crypto";
import { ApiError } from "./database.js";
import { questions } from "../shared/workflows.ts";
const text = z.string().trim().min(1).max(1000);
export const workflowSchemas = [
  z.object({
    type: z.literal("workflowStart"),
    kind: z.enum(["intake", "medication", "release", "custody"]),
  }),
  z.object({
    type: z.literal("workflowAnswer"),
    id: text,
    key: text,
    value: text,
  }),
  z.object({ type: z.literal("workflowBack"), id: text }),
  z.object({ type: z.literal("workflowCancel"), id: text }),
  z.object({ type: z.literal("workflowComplete"), id: text }),
  z.object({
    type: z.literal("medicationOrder"),
    order: z
      .object({
        residentId: text,
        medication: text,
        dose: text,
        route: text,
        schedule: text,
        prescriber: text,
        reference: text,
        starts: z.iso.date(),
        ends: z.iso.date(),
      })
      .strict(),
  }),
  z.object({ type: z.literal("medicationOrderStop"), id: text }),
];
const fail = (message) => {
  throw new ApiError(409, message);
};
export function validateWorkflow(s, a, user, proof) {
  if (a.type === "medicationOrder") {
    if (user.role !== "admin")
      throw new ApiError(
        403,
        "An administrator must transcribe authorized orders.",
      );
    if (!s.residents.some((r) => r.id === a.order.residentId))
      fail("Select an active resident.");
    if (a.order.ends < a.order.starts)
      fail("The end date must follow the start date.");
    a.order = {
      ...a.order,
      id: randomUUID(),
      createdBy: user.username,
      active: true,
    };
    return;
  }
  if (a.type === "medicationOrderStop") {
    if (user.role !== "admin")
      throw new ApiError(403, "An administrator must discontinue an order.");
    if (!s.workflows.orders.some((o) => o.id === a.id && o.active))
      fail("Order not active.");
    return;
  }
  if (a.type === "workflowStart") {
    a.record = {
      id: randomUUID(),
      kind: a.kind,
      owner: user.username,
      residentId: "",
      step: 0,
      answers: {},
      status: "Draft",
      updated: new Date().toISOString(),
    };
    return;
  }
  if (!a.type.startsWith("workflow")) return;
  const w = s.workflows.records.find((w) => w.id === a.id);
  if (!w || w.status !== "Draft") fail("This workflow is no longer open.");
  if (w.owner !== user.username)
    throw new ApiError(
      403,
      "Only the operator who started this workflow may change it.",
    );
  const qs = questions(w.kind),
    q = qs[w.step];
  if (a.type === "workflowAnswer") {
    if (
      w.answers.screening === "Concern identified · hold for assessment" ||
      w.answers.holds === "Hold unresolved · stop release" ||
      w.answers.property === "Unresolved · stop release"
    )
      fail(
        "Resolve the recorded concern before continuing. Return to the previous question.",
      );
    if (!q || q.key !== a.key) fail("Answer the current question in order.");
    if (q.options && !q.options.includes(a.value))
      fail("Choose one of the listed responses.");
    if (a.key === "residentId" && !s.residents.some((r) => r.id === a.value))
      fail("Select an active resident.");
    if (
      a.key === "age" &&
      (!/^\d+$/.test(a.value) || +a.value < 12 || +a.value > 20)
    )
      fail("Age must be between 12 and 20.");
    if (a.key === "name" && a.value.length > 70)
      fail("Name must be 70 characters or fewer.");
    if (["plan", "caseManager"].includes(a.key) && a.value.length > 100)
      fail("Use 100 characters or fewer.");
    if (a.key === "room" && !/^(A1|A2|B1|B2)\/(0[1-9]|1[0-6])$/.test(a.value))
      fail("Select a valid room.");
    if (a.key === "identity") {
      if (a.value.startsWith("manual:") && a.value.slice(7).trim().length >= 12)
        a.verification = {
          method: "Manual attestation",
          by: user.username,
          at: new Date().toISOString(),
        };
      else {
        const verified = proof?.(a.value, w, user);
        if (!verified)
          fail("Verification expired or does not match this workflow.");
        a.verification = verified;
      }
      a.value =
        a.verification.method +
        (a.value.startsWith("manual:") ? " · " + a.value.slice(7).trim() : "");
    }
    if (
      a.key === "outcome" &&
      a.value === "Given" &&
      w.answers.rights !== "All checks complete"
    )
      fail("An unresolved administration check cannot be recorded as given.");
    if (a.key === "orderId") checkOrder(s, w, a.value);
  }
  if (a.type === "workflowComplete") {
    if (w.step !== qs.length || !w.verification)
      fail("Complete all questions and identity verification first.");
    if (w.kind !== "intake" && !s.residents.some((r) => r.id === w.residentId))
      fail("The resident is no longer active.");
    if (w.kind === "intake") {
      if (w.answers.screening !== "Completed · no unresolved concern")
        fail("Resolve the welfare concern before admission.");
      const [unit, room] = w.answers.room.split("/");
      if (s.residents.some((r) => r.unit === unit && r.room === room))
        fail("That room is occupied. Go back and choose another placement.");
      a.resident = {
        id: `R-${Math.max(1048, ...[...s.residents, ...s.discharged].map((r) => Number(r.id.split("-")[1]) || 0)) + 1}`,
        name: w.answers.name,
        age: +w.answers.age,
        unit,
        room,
        caseManager: w.answers.caseManager,
        plan: w.answers.plan,
        status: "In unit",
        admitted: new Date().toISOString(),
      };
    }
    if (
      w.kind === "release" &&
      (w.answers.holds !== "Checked · clear for release" ||
        w.answers.property !== "Reconciled and ready")
    )
      fail("Resolve custody holds and handover requirements before release.");
    if (w.kind === "medication") {
      checkOrder(s, w, w.answers.orderId);
      if (
        w.answers.outcome === "Given" &&
        w.answers.rights !== "All checks complete"
      )
        fail("A dose cannot be marked given while a check is unresolved.");
    }
  }
}
function checkOrder(s, w, id) {
  const today = new Date().toISOString().slice(0, 10);
  if (
    !s.workflows.orders.some(
      (o) =>
        o.id === id &&
        o.residentId === w.residentId &&
        o.active &&
        o.starts <= today &&
        o.ends >= today,
    )
  )
    fail("Select a current, active order for this resident.");
}
