import {
  createHmac,
  randomBytes,
  randomUUID,
  timingSafeEqual,
} from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { z } from "zod";
import { ApiError } from "./database.js";
export function registerVerification(app, store, config, authenticate, csrf) {
  const secretFile = path.join(config.dataDir, "reader-key");
  if (!existsSync(secretFile))
    writeFileSync(secretFile, randomBytes(32), { mode: 0o600, flag: "wx" });
  const key = readFileSync(secretFile);
  const digest = (value) =>
    createHmac("sha256", key).update(value).digest("hex");
  store.db
    .exec(`CREATE TABLE IF NOT EXISTS reader_credentials (digest TEXT PRIMARY KEY, resident_id TEXT NOT NULL, enrolled_by TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS reader_challenges (nonce TEXT PRIMARY KEY, workflow_id TEXT NOT NULL, owner TEXT NOT NULL, subject TEXT NOT NULL, expires INTEGER NOT NULL, consumed INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS reader_proofs (id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL, owner TEXT NOT NULL, subject TEXT NOT NULL, method TEXT NOT NULL, expires INTEGER NOT NULL);`);
  const fingerprintKey =
    config.fingerprintKey || process.env.FINGERPRINT_BRIDGE_KEY || "";
  const workflow = (id, user) => {
    const w = store
      .snapshot()
      .state.workflows.records.find(
        (w) => w.id === id && w.status === "Draft" && w.owner === user.username,
      );
    if (!w) throw new ApiError(404, "Open one of your own workflows first.");
    return w;
  };
  const subject = (w) => w.residentId || w.id;
  const grant = (w, user, method) => {
    const id = randomUUID();
    store.db
      .prepare("INSERT INTO reader_proofs VALUES (?,?,?,?,?,?)")
      .run(id, w.id, user.username, subject(w), method, Date.now() + 120000);
    return id;
  };
  const auditReader = (actor, action, title, residentId) =>
    store.db
      .prepare(
        "INSERT INTO audit (id, occurred_at, actor, action, title, detail) VALUES (?, ?, ?, ?, ?, ?)",
      )
      .run(
        randomUUID(),
        new Date().toISOString(),
        actor,
        action,
        title,
        residentId,
      );
  const parse = (schema, value) => {
    const p = schema.safeParse(value);
    if (!p.success) throw new ApiError(400, "Check the reader request fields.");
    return p.data;
  };
  const str = z.string().trim().min(1).max(200);
  const card = z
    .string()
    .min(4)
    .max(120)
    .regex(
      /^[a-zA-Z0-9._:-]+$/,
      "Use a facility identifier, not payment card track data.",
    );
  app.get("/api/readers", authenticate, (_req, res) =>
    res.json({
      fingerprintConfigured: fingerprintKey.length >= 32,
      bridgeUrl: "http://127.0.0.1:17443",
      cardMode: "Keyboard wedge · facility identifiers only",
      fingerprintStatus:
        fingerprintKey.length >= 32
          ? "WBF bridge configured; physical reader status checked at workstation"
          : "WBF workstation bridge not configured",
    }),
  );
  app.post("/api/readers/enroll", authenticate, csrf, (req, res) => {
    if (req.auth.user.role !== "admin")
      throw new ApiError(403, "Administrator enrollment required.");
    const b = parse(
      z.object({ residentId: str, credential: card }).strict(),
      req.body,
    );
    if (!store.snapshot().state.residents.some((r) => r.id === b.residentId))
      throw new ApiError(404, "Resident not found.");
    try {
      store.db
        .prepare("INSERT INTO reader_credentials VALUES (?,?,?)")
        .run(digest(b.credential), b.residentId, req.auth.user.username);
    } catch {
      throw new ApiError(409, "This identifier is already enrolled.");
    }
    auditReader(
      req.auth.user.username,
      "readerEnroll",
      "Facility identifier enrolled",
      b.residentId,
    );
    res.json({ enrolled: true });
  });
  app.post("/api/readers/revoke", authenticate, csrf, (req, res) => {
    if (req.auth.user.role !== "admin")
      throw new ApiError(403, "Administrator required.");
    const b = parse(z.object({ residentId: str }).strict(), req.body);
    store.db
      .prepare("DELETE FROM reader_credentials WHERE resident_id=?")
      .run(b.residentId);
    store.db
      .prepare("DELETE FROM reader_proofs WHERE subject=? AND method=?")
      .run(b.residentId, "Facility card match");
    auditReader(
      req.auth.user.username,
      "readerRevoke",
      "Facility identifiers revoked",
      b.residentId,
    );
    res.json({ revoked: true });
  });
  app.post("/api/readers/card", authenticate, csrf, (req, res) => {
    const b = parse(
        z.object({ workflowId: str, credential: card }).strict(),
        req.body,
      ),
      w = workflow(b.workflowId, req.auth.user);
    const entry = store.db
      .prepare("SELECT resident_id FROM reader_credentials WHERE digest=?")
      .get(digest(b.credential));
    if (!entry || entry.resident_id !== subject(w))
      throw new ApiError(
        409,
        "Identifier does not match the selected resident.",
      );
    res.json({ proof: grant(w, req.auth.user, "Facility card match") });
  });
  app.post("/api/readers/challenge", authenticate, csrf, (req, res) => {
    if (fingerprintKey.length < 32)
      throw new ApiError(
        503,
        "Configure the Windows SDK adapter before fingerprint verification.",
      );
    const b = parse(z.object({ workflowId: str }).strict(), req.body),
      w = workflow(b.workflowId, req.auth.user);
    const nonce = randomBytes(32).toString("hex"),
      expires = Date.now() + 60000;
    store.db
      .prepare("DELETE FROM reader_challenges WHERE expires < ?")
      .run(Date.now());
    store.db
      .prepare("DELETE FROM reader_proofs WHERE expires < ?")
      .run(Date.now());
    store.db
      .prepare(
        "INSERT INTO reader_challenges (nonce,workflow_id,owner,subject,expires) VALUES (?,?,?,?,?)",
      )
      .run(nonce, w.id, req.auth.user.username, subject(w), expires);
    res.json({
      nonce,
      subject: subject(w),
      expires,
      operator: req.auth.user.username,
    });
  });
  app.post("/api/readers/fingerprint", authenticate, csrf, (req, res) => {
    const b = parse(
      z
        .object({
          nonce: str,
          subject: str,
          residentCheck: z.string().trim().min(12).max(900),
          signature: z.string().regex(/^[a-f0-9]{64}$/),
        })
        .strict(),
      req.body,
    );
    const c = store.db
      .prepare("SELECT * FROM reader_challenges WHERE nonce=?")
      .get(b.nonce);
    if (
      !c ||
      c.consumed ||
      c.expires < Date.now() ||
      c.owner !== req.auth.user.username ||
      c.subject !== b.subject
    )
      throw new ApiError(
        409,
        "The fingerprint challenge is invalid or expired.",
      );
    if (fingerprintKey.length < 32)
      throw new ApiError(503, "Fingerprint adapter not configured.");
    const expected = createHmac("sha256", fingerprintKey)
      .update(
        `${b.nonce}\n${b.subject}\n${req.auth.user.username}\nstaff-wbf-matched`,
      )
      .digest();
    if (!timingSafeEqual(expected, Buffer.from(b.signature, "hex")))
      throw new ApiError(403, "Untrusted fingerprint result.");
    const w = workflow(c.workflow_id, req.auth.user);
    if (subject(w) !== b.subject)
      throw new ApiError(409, "Resident selection changed.");
    store.db
      .prepare("UPDATE reader_challenges SET consumed=1 WHERE nonce=?")
      .run(b.nonce);
    res.json({
      proof: grant(
        w,
        req.auth.user,
        "Staff fingerprint · WBF; resident check: " + b.residentCheck,
      ),
    });
  });
  return (id, w, user) => {
    const p = store.db
      .prepare("SELECT * FROM reader_proofs WHERE id=?")
      .get(id);
    if (
      !p ||
      p.expires < Date.now() ||
      p.workflow_id !== w.id ||
      p.owner !== user.username ||
      p.subject !== subject(w)
    )
      return null;
    // Called inside the workspace transaction: consumption rolls back if the action fails.
    store.db.prepare("DELETE FROM reader_proofs WHERE id=?").run(id);
    return {
      method: p.method,
      by: user.username,
      at: new Date().toISOString(),
    };
  };
}
