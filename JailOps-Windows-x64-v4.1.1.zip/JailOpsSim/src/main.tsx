import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { SimulationProvider } from "./store";
import "@fontsource/dm-sans/latin-400.css";
import "@fontsource/dm-sans/latin-500.css";
import "@fontsource/dm-sans/latin-600.css";
import "@fontsource/manrope/latin-400.css";
import "@fontsource/manrope/latin-500.css";
import "@fontsource/manrope/latin-600.css";
import "@fontsource/manrope/latin-700.css";
import "@fontsource/manrope/latin-800.css";
import "./palette.css";
import "./styles.css";
import "./expansion.css";
import "./workflows.css";

try {
  document.documentElement.dataset.theme =
    localStorage.getItem("jailops-theme") || "light";
} catch {
  document.documentElement.dataset.theme = "light";
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <SimulationProvider>
      <App />
    </SimulationProvider>
  </React.StrictMode>,
);
