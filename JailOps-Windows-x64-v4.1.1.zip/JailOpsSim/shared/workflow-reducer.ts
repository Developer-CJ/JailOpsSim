import { questions } from "./workflows.ts";
import type { Simulation } from "./model.ts";
import type { Workflow, MedicationOrder } from "./workflows.ts";
export type WorkflowAction =
  | { type: "workflowStart"; kind: Workflow["kind"]; record?: Workflow }
  | {
      type: "workflowAnswer";
      id: string;
      key: string;
      value: string;
      verification?: Workflow["verification"];
    }
  | {
      type: "workflowBack" | "workflowCancel" | "workflowComplete";
      id: string;
      resident?: Simulation["residents"][number];
    }
  | {
      type: "medicationOrder";
      order: Omit<MedicationOrder, "id" | "createdBy" | "active">;
    }
  | { type: "medicationOrderStop"; id: string };
export function reduceWorkflow(s: Simulation, a: WorkflowAction): Simulation {
  const at = new Date().toISOString();
  let next = { ...s, workflows: { ...s.workflows } };
  if (a.type === "medicationOrder")
    next.workflows.orders = [
      { ...a.order } as MedicationOrder,
      ...s.workflows.orders,
    ];
  else if (a.type === "medicationOrderStop")
    next.workflows.orders = s.workflows.orders.map((o) =>
      o.id === a.id ? { ...o, active: false } : o,
    );
  else if (a.type === "workflowStart") {
    if (!a.record) return s;
    next.workflows.records = [a.record, ...s.workflows.records];
  } else {
    const w = s.workflows.records.find((w) => w.id === a.id);
    if (!w) return s;
    let updated = { ...w, updated: at };
    if (a.type === "workflowAnswer")
      updated = {
        ...updated,
        step: w.step + 1,
        answers: { ...w.answers, [a.key]: a.value },
        residentId: a.key === "residentId" ? a.value : w.residentId,
        verification: a.verification ?? w.verification,
      };
    if (a.type === "workflowBack") {
      updated.step = Math.max(0, w.step - 1);
      const kept = questions(w.kind)
        .slice(0, updated.step)
        .map((q) => q.key);
      updated.answers = Object.fromEntries(
        Object.entries(w.answers).filter(([key]) => kept.includes(key)),
      );
      if (!kept.includes("residentId")) updated.residentId = "";
      if (!kept.includes("identity")) updated.verification = undefined;
    }
    if (a.type === "workflowCancel") updated.status = "Cancelled";
    if (a.type === "workflowComplete") {
      updated.status = "Completed";
      updated.completed = at;
      if (w.kind === "intake" && a.resident) {
        next.residents = [a.resident, ...s.residents];
        updated.residentId = a.resident.id;
      }
      if (w.kind === "custody") {
        const person = s.residents.find((r) => r.id === w.residentId)!;
        const destination: Record<string, string> = {
          "Housing unit": person.unit,
          "Health services": "MED",
          Education: "EDU",
          "Court transport": "INT",
          "Family visitation": "INT",
        };
        const zone = destination[w.answers.destination];
        next.extension = {
          ...s.extension,
          locations: { ...s.extension.locations, [person.id]: zone },
          movements: [
            {
              id: crypto.randomUUID(),
              residentId: person.id,
              residentName: person.name,
              origin: s.extension.locations[person.id] || person.unit,
              destination: zone,
              escort: w.answers.escort,
              purpose: `Custody handoff · ${w.answers.handoff}`,
              status: "Arrived",
              created: at,
              updated: at,
            },
            ...s.extension.movements,
          ],
        };
        next.residents = s.residents.map((r) =>
          r.id === person.id
            ? {
                ...r,
                status:
                  zone === "MED"
                    ? "Health services"
                    : zone === "EDU"
                      ? "In program"
                      : "In unit",
              }
            : r,
        );
      }
      if (w.kind === "release") {
        const resident = s.residents.find((r) => r.id === w.residentId)!;
        next.extension = {
          ...s.extension,
          locations: Object.fromEntries(
            Object.entries(s.extension.locations).filter(
              ([id]) => id !== w.residentId,
            ),
          ),
          movements: s.extension.movements.map((m) =>
            m.residentId === w.residentId &&
            ["Queued", "En route"].includes(m.status)
              ? { ...m, status: "Cancelled", updated: at }
              : m,
          ),
        };
        next.residents = s.residents.filter((r) => r.id !== w.residentId);
        next.discharged = [
          { ...resident, dischargedAt: at, reason: w.answers.reason },
          ...s.discharged,
        ];
        next.programs = s.programs.map((p) => ({
          ...p,
          roster: p.roster.filter((id) => id !== w.residentId),
        }));
        next.appointments = s.appointments.map((p) =>
          p.residentId === w.residentId && p.status !== "Completed"
            ? { ...p, status: "Cancelled" as const }
            : p,
        );
      }
    }
    next.workflows.records = s.workflows.records.map((r) =>
      r.id === w.id ? updated : r,
    );
  }
  const encounter =
    "id" in a ? s.workflows.records.find((w) => w.id === a.id) : undefined;
  return {
    ...next,
    activity: [
      {
        id: crypto.randomUUID(),
        time: at,
        title:
          a.type === "workflowComplete"
            ? "Workflow completed"
            : a.type === "medicationOrder"
              ? "Medication order recorded"
              : "Workflow updated",
        detail: encounter
          ? `${encounter.id} · ${encounter.kind} · ${encounter.residentId || encounter.answers.name} · ${encounter.answers.outcome || encounter.answers.reason || ""}`
          : a.type,
        type: "resident" as const,
      },
      ...s.activity,
    ].slice(0, 250),
  };
}
