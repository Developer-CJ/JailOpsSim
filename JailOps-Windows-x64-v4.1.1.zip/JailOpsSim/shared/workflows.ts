export const release = {
  version: "4.1.1",
  build: 1,
  storage: 1,
  storageLabel: "Local SQLite",
} as const;
export type WorkflowKind = "intake" | "medication" | "release" | "custody";
export type Workflow = {
  id: string;
  kind: WorkflowKind;
  owner: string;
  residentId: string;
  step: number;
  answers: Record<string, string>;
  status: "Draft" | "Completed" | "Cancelled";
  updated: string;
  verification?: { method: string; by: string; at: string };
  completed?: string;
};
export type MedicationOrder = {
  id: string;
  residentId: string;
  medication: string;
  dose: string;
  route: string;
  schedule: string;
  prescriber: string;
  reference: string;
  starts: string;
  ends: string;
  createdBy: string;
  active: boolean;
};
export type WorkflowState = { records: Workflow[]; orders: MedicationOrder[] };
export const initialWorkflows = (): WorkflowState => ({
  records: [],
  orders: [],
});
export type Question = {
  key: string;
  title: string;
  hint: string;
  options?: string[];
  input?: "resident" | "room" | "order" | "number" | "date" | "identity";
};
const identity: Question = {
  key: "identity",
  title: "Confirm who is in front of you.",
  hint: "Match the person to their record. A manual check is recorded as an attestation, never as a fingerprint match.",
  input: "identity",
};
export function questions(kind: WorkflowKind): Question[] {
  const person: Question = {
    key: "residentId",
    title: "Who are you working with?",
    hint: "Select the resident record before continuing.",
    input: "resident",
  };
  if (kind === "intake")
    return [
      {
        key: "name",
        title: "Who is arriving today?",
        hint: "Enter the full name from the admission documents.",
      },
      {
        key: "age",
        title: "What is their age?",
        hint: "Age in completed years, from the admission documents.",
        input: "number",
      },
      {
        key: "authority",
        title: "What authorizes this admission?",
        hint: "Record the court order or placement authority reference.",
      },
      {
        key: "screening",
        title: "Has the arrival welfare screening been completed?",
        hint: "An unresolved concern stops admission. Arrange a qualified assessment before proceeding.",
        options: [
          "Completed · no unresolved concern",
          "Concern identified · hold for assessment",
        ],
      },
      {
        key: "room",
        title: "Where will they be placed?",
        hint: "Only vacant rooms can be selected. Occupancy is checked again when you commit.",
        input: "room",
      },
      identity,
      {
        key: "caseManager",
        title: "Who is coordinating their care?",
        hint: "Record the assigned case coordinator.",
      },
      {
        key: "plan",
        title: "What needs to happen next?",
        hint: "Record an immediate care and orientation plan.",
      },
    ];
  if (kind === "release")
    return [
      person,
      {
        key: "authority",
        title: "What authorizes this release?",
        hint: "Enter the verified court or placement order reference. This entry does not validate an order with a court.",
      },
      {
        key: "holds",
        title: "Have outstanding holds been checked?",
        hint: "Use the authoritative court and custody records before confirming.",
        options: [
          "Checked · clear for release",
          "Hold unresolved · stop release",
        ],
      },
      identity,
      {
        key: "recipient",
        title: "Who is receiving custody?",
        hint: "Record their name, relationship or agency, and the identity document reference checked.",
      },
      {
        key: "property",
        title: "Is the handover ready?",
        hint: "Confirm property reconciliation, medication handover where applicable, transport, and written transition instructions.",
        options: ["Reconciled and ready", "Unresolved · stop release"],
      },
      {
        key: "witness",
        title: "Who witnessed the handover review?",
        hint: "Record a second staff member’s name. This is an attestation; it is not a second authenticated signature.",
      },
      {
        key: "reason",
        title: "What is the release pathway?",
        hint: "Choose the destination recorded in the authorizing documents.",
        options: [
          "Community transition",
          "Family reunification",
          "Placement transfer",
        ],
      },
    ];
  if (kind === "medication")
    return [
      person,
      {
        key: "orderId",
        title: "Which authorized medication order?",
        hint: "Select a current order entered from a prescriber’s instruction. JailOps does not prescribe or calculate doses.",
        input: "order",
      },
      identity,
      {
        key: "rights",
        title: "Do the administration checks agree?",
        hint: "Check the person, medication, dose, route, scheduled time, allergies and current instructions against the authoritative order.",
        options: ["All checks complete", "Mismatch or concern · hold"],
      },
      {
        key: "outcome",
        title: "What actually happened?",
        hint: "Record the observed outcome. Refused, held, and omitted doses are never marked as given.",
        options: ["Given", "Refused", "Held", "Omitted"],
      },
      {
        key: "notes",
        title: "Document the encounter.",
        hint: "Record the administration time, observations, or the reason and escalation for a dose not given.",
      },
    ];
  return [
    person,
    identity,
    {
      key: "destination",
      title: "Where is custody moving?",
      hint: "Select the receiving location.",
      options: [
        "Housing unit",
        "Health services",
        "Education",
        "Court transport",
        "Family visitation",
      ],
    },
    {
      key: "escort",
      title: "Who is responsible for the escort?",
      hint: "Record the escorting staff member or transport team.",
    },
    {
      key: "handoff",
      title: "Has the receiving staff accepted custody?",
      hint: "Confirm the arrival and the receiving staff member before recording completion.",
    },
  ];
}
