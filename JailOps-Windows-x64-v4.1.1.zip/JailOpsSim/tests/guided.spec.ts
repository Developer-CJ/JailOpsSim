import { expect, test } from "@playwright/test";
import type { Page } from "@playwright/test";
import { testAdmin } from "./credentials.js";

test.beforeEach(async ({ page }) => {
  const session = await (
    await page.request.post("/api/login", { data: testAdmin })
  ).json();
  const snapshot = await (await page.request.get("/api/state")).json();
  expect(
    (
      await page.request.post("/api/actions", {
        headers: {
          "X-CSRF-Token": session.csrfToken,
          "If-Match": `"${snapshot.revision}"`,
        },
        data: { type: "reset" },
      })
    ).ok(),
  ).toBe(true);
});
async function next(page: Page) {
  await page.getByRole("button", { name: "Continue", exact: true }).click();
}
async function manual(page: Page) {
  await page
    .getByLabel("Two identifiers checked and source reference")
    .fill("Name and wristband checked against fixture order.");
  await page.getByRole("button", { name: "Record manual attestation" }).click();
}
async function review(page: Page, button: string) {
  await expect(
    page.getByRole("heading", { name: "Pause. Review. Confirm." }),
  ).toBeVisible();
  await page.getByRole("checkbox", { name: /confirm this record/ }).check();
  await page.getByRole("button", { name: button, exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Encounter recorded." }),
  ).toBeVisible();
}

test("workflow desk fits both themes and mobile; dialogs save drafts and restore keyboard focus", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(page.locator(".desk-hero h1")).toContainText("Care in every");
  await expect(page.locator(".path-card")).toHaveCount(4);
  for (const theme of ["light", "dark"]) {
    await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
    for (const viewport of [
      { width: 1440, height: 1000 },
      { width: 390, height: 844 },
    ]) {
      await page.setViewportSize(viewport);
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
      ).toBe(true);
      await page.getByRole("button", { name: /01 \/ ADMISSIONS/ }).click();
      await expect(
        page.getByRole("heading", { name: "Who is arriving today?" }),
      ).toBeVisible();
      expect(
        await page
          .locator("[role=dialog]")
          .evaluate((e) => e.scrollWidth <= e.clientWidth),
      ).toBe(true);
      await page.getByLabel("Who is arriving today?").fill("Draft Youth");
      await next(page);
      await expect(
        page.getByRole("heading", { name: "What is their age?" }),
      ).toBeVisible();
      await page.keyboard.press("Escape");
      await expect(page.getByRole("dialog")).toHaveCount(0);
      await page.locator(".draft-row").first().click();
      await expect(
        page.getByRole("heading", { name: "What is their age?" }),
      ).toBeVisible();
      await page
        .getByRole("button", { name: "Cancel workflow", exact: true })
        .click();
    }
    if (theme === "light")
      await page.getByRole("button", { name: "Switch to dark mode" }).click();
  }
  expect(errors).toEqual([]);
});

test("intake interview pauses for a concern, resumes after revision, and commits an admission once", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Begin an intake" }).click();
  await page.getByLabel("Who is arriving today?").fill("Guided Intake Youth");
  await next(page);
  await page.getByLabel("Age", { exact: true }).fill("16");
  await next(page);
  await page
    .getByLabel("What authorizes this admission?")
    .fill("FIXTURE-COURT-77");
  await next(page);
  await page.getByRole("button", { name: /Concern identified/ }).click();
  await next(page);
  await expect(
    page.getByRole("heading", { name: "Pause this pathway." }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Previous question" }).click();
  await page
    .getByRole("button", { name: /Completed · no unresolved concern/ })
    .click();
  await next(page);
  await page.getByLabel("Vacant room").selectOption("A1/13");
  await next(page);
  await manual(page);
  await page
    .getByLabel("Who is coordinating their care?")
    .fill("Fixture coordinator");
  await next(page);
  await page
    .getByLabel("What needs to happen next?")
    .fill("Orientation and arrival support.");
  await next(page);
  await expect(
    page.getByRole("button", { name: "Commit admission" }),
  ).toBeDisabled();
  await review(page, "Commit admission");
  await page.getByRole("button", { name: "Return to desk" }).click();
  const state = (await (await page.request.get("/api/state")).json()).state;
  expect(
    state.residents.filter(
      (r: { name: string }) => r.name === "Guided Intake Youth",
    ),
  ).toHaveLength(1);
  await page.reload();
  await expect(page.locator(".ledger-row")).toContainText(
    "Guided Intake Youth",
  );
});

test("medication pass transcribes an order and records a held dose without offering given", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Medication orders", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Record an authorized order" })
    .click();
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1001");
  for (const [label, value] of [
    ["Medication as ordered", "Fixture medication"],
    ["Dose as ordered", "Prescribed dose"],
    ["Route as ordered", "Oral"],
    ["Scheduled time / instructions", "08:00 per fixture order"],
    ["Prescriber", "Fixture prescriber"],
    ["Authoritative order reference", "FIXTURE-RX-7"],
  ])
    await page.getByLabel(label, { exact: true }).fill(value);
  await page.getByRole("button", { name: "Save authorized order" }).click();
  await expect(page.locator(".order-item")).toContainText("Fixture medication");
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: /02 \/ RESIDENT CARE/ }).click();
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1001");
  await next(page);
  await page.getByLabel("Authorized order").selectOption({ index: 1 });
  await next(page);
  await manual(page);
  await page.keyboard.press("b");
  await expect(
    page.getByRole("button", { name: /Mismatch or concern/ }),
  ).toHaveAttribute("aria-pressed", "true");
  await next(page);
  await expect(
    page.getByRole("button", { name: "A Given", exact: true }),
  ).toHaveCount(0);
  await page.getByRole("button", { name: /Held/, exact: false }).click();
  await next(page);
  await page
    .getByLabel("Document the encounter.")
    .fill("Held at scheduled time. Qualified staff notified of mismatch.");
  await next(page);
  await review(page, "Commit encounter");
  expect(
    (await (await page.request.get("/api/state")).json()).state.workflows
      .records[0].answers.outcome,
  ).toBe("Held");
});

test("facility-card enrollment matches the selected resident during a connected custody handoff", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Verification devices", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "U.are.U 4500 / WBF" }),
  ).toBeVisible();
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1001");
  await page
    .getByLabel("Scan facility identifier", { exact: true })
    .fill("FACILITY-TEST-1001");
  await page.getByRole("button", { name: "Enroll identifier" }).click();
  await expect(page.getByRole("status")).toHaveText(
    "Facility identifier enrolled.",
  );
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: /03 \/ ACCOUNTABILITY/ }).click();
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1001");
  await next(page);
  await page.getByRole("button", { name: "Fingerprint", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Verify staff fingerprint" }),
  ).toBeDisabled();
  await expect(page.locator(".scanner-state")).toContainText(
    "WBF workstation bridge not configured",
  );
  await page
    .getByRole("button", { name: "Facility card", exact: true })
    .click();
  await page
    .getByLabel("Scan facility identifier", { exact: true })
    .fill("WRONG-CARD");
  await page.getByRole("button", { name: "Verify identifier" }).click();
  await expect(page.getByRole("alert")).toContainText("does not match");
  await page
    .getByLabel("Scan facility identifier", { exact: true })
    .fill("FACILITY-TEST-1001");
  await page.getByRole("button", { name: "Verify identifier" }).click();
  await page
    .getByRole("button", { name: /Health services/, exact: false })
    .click();
  await next(page);
  await page
    .getByLabel("Who is responsible for the escort?")
    .fill("Fixture escort");
  await next(page);
  await page
    .getByLabel("Has the receiving staff accepted custody?")
    .fill("Receiving nurse acknowledged arrival.");
  await next(page);
  await review(page, "Commit encounter");
  const state = (await (await page.request.get("/api/state")).json()).state;
  expect(state.extension.locations["R-1001"]).toBe("MED");
  expect(state.extension.movements[0].status).toBe("Arrived");
});

test("release interview records handover and moves the resident to the discharge archive", async ({
  page,
}) => {
  await page.goto("/");
  await page.getByRole("button", { name: /04 \/ TRANSITIONS/ }).click();
  await page.getByLabel("Resident", { exact: true }).selectOption("R-1001");
  await next(page);
  await page
    .getByLabel("What authorizes this release?")
    .fill("FIXTURE-RELEASE-9");
  await next(page);
  await page
    .getByRole("button", { name: /Checked · clear for release/ })
    .click();
  await next(page);
  await manual(page);
  await page
    .getByLabel("Who is receiving custody?")
    .fill("Fixture guardian, document reference checked.");
  await next(page);
  await page.getByRole("button", { name: /Reconciled and ready/ }).click();
  await next(page);
  await page
    .getByLabel("Who witnessed the handover review?")
    .fill("Fixture staff witness");
  await next(page);
  await page.getByRole("button", { name: /Family reunification/ }).click();
  await next(page);
  await review(page, "Commit release");
  const state = (await (await page.request.get("/api/state")).json()).state;
  expect(state.residents.some((r: { id: string }) => r.id === "R-1001")).toBe(
    false,
  );
  expect(state.discharged[0].id).toBe("R-1001");
});
